<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch" style="background: #EEF5F9;">

    <?php
    include("includes/leftmenu.php");
    ?>

    <!--CODE IS ART-->
    <?php
    $variable = isset($_GET['xun']) ? $_GET['xun'] : "manage";

    if ($variable == "manage") { ?>

        <div class="content-inner" style="height:100vh!important">
            <h5>Unapproved Students</h5>
            <!--***** CONTENT *****-->
            <div class="row">
                <table class="table table-hover table-bordered table-responsive">
                    <thead>
                        <tr class="text-white" style="background: #b584bf!important">
                            <?php if ($_SESSION['role'] == 1) { ?>
                                <th>Action</th>
                            <?php } ?>
                            <th>#</th>
                            <th>Profile Picture</th>
                            <th>Username</th>
                            <th>Full Name</th>
                            <th>Gender</th>
                            <th>Course Enrolled</th>
                            <th>Status</th>
                            <th>Joined</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $sl = 1;
                        $sql = "SELECT * FROM user WHERE user_role = 2 && user_status = 420 ORDER BY user_id DESC";
                        $query = mysqli_query($db, $sql);
                        while ($row = mysqli_fetch_assoc($query)) {
                            $user_id = $row['user_id'];
                            $user_pp = $row['user_pp'];
                            $user_username = $row['user_username'];
                            $user_fullname = $row['user_fullname'];
                            $user_gender = $row['user_gender'];
                            $user_course = $row['user_course'];
                            $user_status = $row['user_status'];
                            $user_joined = $row['user_joined'];
                        ?>
                            <tr>
                                <?php if ($_SESSION['role'] == 1) { ?>
                                    <td>
                                        <ul>
                                            <li style="list-style: none;">
                                                <a href="#" data-toggle="modal" data-target="#deleteuser<?php echo $user_username; ?>" class="mr-1" style="color:#d657ab" data-toggle="tooltip" data-placement="top" title="Delete the information of this user"> <i class="fas fa-trash-alt"></i></a>


                                                <a href="unapproved.php?xun=edit&edit_user=<?php echo $user_username; ?>" style="color:#62bede" data-toggle="tooltip" data-placement="top" title="Click to update the information of this user"><i class="fas fa-pen-nib"></i></a>
                                            </li>
                                        </ul>
                                    </td>
                                    <!-- DELETE MODAL START-->
                                    <div class="modal fade" id="deleteuser<?php echo $user_username; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog upor_theke_niche_margin" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">You are deleting all the information of <?php echo $user_fullname; ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="unapproved.php?xun=delete&delete_user=<?php echo $user_username; ?>" class="btn mr-4" style="background-color:#d657ab; color:#fff;">Delete</a>
                                                    <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- DELETE MODAL END-->
                                <?php } ?>

                                <td><?php echo $sl; ?></td>
                                <td>
                                    <?php
                                    if ($user_pp) { ?>
                                        <img src="img/user/<?php echo $user_pp; ?>" alt="Profile picture" width="30" height="20">
                                    <?php } else if (empty($user_pp) && $user_gender == 1) { ?>
                                        <img src="img/user/default/male.png" alt="Profile picture" width="30">
                                    <?php } else if (empty($user_pp) && $user_gender == 2) { ?>
                                        <img src="img/user/default/female.png" alt="Profile picture" width="30">
                                    <?php }
                                    ?>
                                </td>
                                <td><?php echo $user_username; ?></td>
                                <td><?php echo $user_fullname; ?> </td>
                                <td>
                                    <?php
                                    if ($user_gender == 1) { ?>
                                        Male
                                    <?php } else if ($user_gender == 2) { ?>
                                        Female
                                    <?php }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    $sql = "SELECT * FROM course WHERE course_id = '$user_course'";
                                    $new_query = mysqli_query($db, $sql);
                                    while ($new_row = mysqli_fetch_assoc($new_query)) {
                                        $course_id = $new_row['course_id'];
                                        $course_name = $new_row['course_name'];
                                    }
                                    if (!empty($course_id)) {
                                        echo $course_name;
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php
                                    if ($user_status == 1) { ?>
                                        <span class="badge badge-pill" style="background: #59ce90;">Active student</span>
                                    <?php } else if ($user_status == 420) { ?>
                                        <span class="badge badge-pill" style="background: #d657ab;">Inactive student</span>
                                    <?php }
                                    ?>
                                </td>
                                <td><?php echo $user_joined; ?></td>
                            </tr>
                        <?php
                            $sl++;
                        }

                        ?>
                    </tbody>

                </table>
            </div>

        </div>
        <?php }


    if ($_SESSION['role'] == 1) {

        if ($variable == "edit") { ?>
            <div class="content-inner chart-cont">

                <!--***** FORM LAYOUTS *****-->
                <div class="row">
                    <div class="col-md-12">

                        <!--***** USER INFO *****-->
                        <div class="card form" id="form1">

                            <?php
                            if (isset($_GET['edit_user'])) {
                                $store_edit = $_GET['edit_user'];

                                $sql = "SELECT * FROM user WHERE user_username = '$store_edit' ";
                                $query = mysqli_query($db, $sql);
                                while ($row = mysqli_fetch_assoc($query)) {

                                    $user_username = $row['user_username'];
                                    $user_fullname = $row['user_fullname'];
                                    $user_status = $row['user_status'];
                            ?>
                                    <div class="card-header">
                                        <h3><i class="fa fa-user-circle"></i> Edit <?php echo $user_fullname . "'s"; ?> status</h3>
                                    </div>
                                    <br>

                                    <form method="POST" action="unapproved.php?xun=update">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Status</label>
                                                    <div class="custom_color_radio">
                                                        <input name="status" value="1" type="radio" id="status_for_active" <?php if ($user_status == 1) {
                                                                                                                                echo "checked";
                                                                                                                            }  ?>>
                                                        <label for="status_for_active">Active</label>

                                                        <input name="status" value="420" type="radio" id="status_for_inactive" <?php if ($user_status == 420) {
                                                                                                                                    echo "checked";
                                                                                                                                }  ?>>
                                                        <label for="status_for_inactive">Inactive</label>
                                                    </div>
                                                </div>


                                                <input type="submit" class="btn btn-general" value="update status" style="color:#495057; border:0.7px solid #7ca4c7">

                                                <input type="hidden" name="update_user" value="<?php echo $user_username; ?>">
                                            </div>
                                            <!--Card-->
                                    </form>

                            <?php } //while end
                            } ?>
                        </div>
                        <!--Column-->

                    </div>
                    <!--Row-->
                </div>
                <!--content-inner chart-cont-->


        <?php }
        if ($variable == "update") {

            if (isset($_POST['update_user'])) {
                $store_update = $_POST['update_user'];

                $user_status = mysqli_real_escape_string($db, $_POST['status']);

                $sql = "UPDATE user SET user_status = '$user_status' WHERE user_username = '$store_update' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    header("location:unapproved.php");
                } else {
                    die("Operation failed" . mysqli_error($db));
                }
            }
        }
        if ($variable == "delete") {
            if (isset($_GET['delete_user'])) {
                $store_delete = $_GET['delete_user'];

                $sql = "DELETE FROM user WHERE user_username = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    header("location:unapproved.php");
                } else {
                    die("Operation failed" . mysqli_error($db));
                }
            }
        }
    } //role 1 condition 
        ?>


            </div>
            <!--Page content-->

            <?php
            include("includes/footer.php")
            ?>