<title>Home &mdash; XUN Board</title>
<?php
include("includes/header.php");
?>

<!--====================================================
                        PAGE CONTENT START
======================================================-->
<div class="page-content d-flex align-items-stretch">

    <!--***** LEFT MENU *****-->
    <?php
    include("includes/leftmenu.php")
    ?>



    <div class="content-inner">


        <!--***** MAPS START *****-->
        <div class="chart-cont">
            <h1 class="py-4 text-center responsive_h1">Our students from all over Bangladesh</h1>
            <div class="row">
                <div class="col-md-6">
                    <div class="card map p-2">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d233667.8223908687!2d90.27923710646988!3d23.78088745708454!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755b8b087026b81%3A0x8fa563bbdd5904c2!2sDhaka!5e0!3m2!1sen!2sbd!4v1603272949459!5m2!1sen!2sbd" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card map p-2">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d58373.54521955562!2d90.22635112307728!3d23.877326075343046!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755ebd3d6df9569%3A0x277b3819d4da3e91!2sSavar%20Union!5e0!3m2!1sen!2sbd!4v1603272721793!5m2!1sen!2sbd" height="400" frameborder="0" style="border:0;" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card map p-2">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57498.00018485155!2d89.22702578343885!3d25.749911571570426!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e32de6fca6019b%3A0x9fa496e687f818c8!2sRangpur!5e0!3m2!1sen!2sbd!4v1603273011498!5m2!1sen!2sbd" height="400" frameborder="0" style="border:0;" allowfullscreen></iframe>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card map p-2">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d29455.03162291199!2d89.75795718663085!3d22.658301352401782!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39fff5d7e37f6e3d%3A0xbb70031cead1d5af!2sBagerhat!5e0!3m2!1sen!2sbd!4v1603272861301!5m2!1sen!2sbd" height="400" frameborder="0" style="border:0;" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
        <!--***** MAPS END *****-->


        <!--***** STUDENTS WORKS START *****-->
        <div class="media-cont py-5">
            <h1 class="py-4 text-center responsive_h1">Some works of our students</h1>
            <div class="row" id="media">
                <div class="row no-gutters">
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/1.jpg" title="Work Description Goes Here">
                                <img src="img/work/1.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/2.jpg" title="Work Description Goes Here">
                                <img src="img/work/2.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/3.jpg" title="Work Description Goes Here">
                                <img src="img/work/3.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/4.jpg" title="Work Description Goes Here">
                                <img src="img/work/4.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/5.jpg" title="Work Description Goes Here">
                                <img src="img/work/5.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/6.jpg" title="Work Description Goes Here">
                                <img src="img/work/6.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/7.jpg" title="Work Description Goes Here">
                                <img src="img/work/7.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/8.jpg" title="Work Description Goes Here">
                                <img src="img/work/8.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="img-wrapper">
                            <a href="img/work/4.jpg" title="Work Description Goes Here">
                                <img src="img/work/4.jpg" class="img-fluid" alt="Work">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--***** STUDENTS WORKS END *****-->


    </div>



</div>
<!--====================================================
                        PAGE CONTENT END
======================================================-->
<?php
include("includes/footer.php")
?>