-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 05, 2022 at 02:07 PM
-- Server version: 10.3.25-MariaDB-log
-- PHP Version: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ct_board_php`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `course_id` int(11) NOT NULL,
  `course_img` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_desc` varchar(255) NOT NULL,
  `course_status` int(11) NOT NULL,
  `course_started` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`course_id`, `course_img`, `course_name`, `course_desc`, `course_status`, `course_started`) VALUES
(1, '602x338_cmsv2_4700a622-4edb-5eee-a662-4c48278cd38c-5014422.jpg', 'Graphic Design', 'Newest course', 420, '2020-10-21'),
(2, 'business-stat.jpg', 'Web Development', 'New course', 420, '2020-10-22'),
(4, 'bg-i.jpg', 'Game Development', '', 420, '2020-10-23'),
(5, '', 'Flutter', '', 420, '2020-10-23'),
(6, '', 'Apps Development', '', 420, '2020-10-23'),
(7, '', 'Video Editing', '', 1, '2020-10-23'),
(8, 'c-4.jpg', 'Digital Marketing', 'This is digital marketing.', 420, '2020-10-23'),
(11, '', '3d Drawing', '', 420, '2020-10-23'),
(12, '', 'Autocad', '', 1, '(01:36:39 AM, Sun, 18 Jul, 2021)');

-- --------------------------------------------------------

--
-- Table structure for table `homework`
--

CREATE TABLE `homework` (
  `id` int(11) NOT NULL,
  `submitted_by` varchar(255) NOT NULL,
  `course_enrolled` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `submit_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `homework`
--

INSERT INTO `homework` (`id`, `submitted_by`, `course_enrolled`, `name`, `details`, `link`, `file`, `submit_date`) VALUES
(3, 'Tahsin Faruque', 0, 'Mockup', '', '', 'g-6.jpg', '(10:47:43 PM, Sun, 01 Nov, 2020)'),
(4, 'Rubaiya Islam', 8, 'Graphics', '', '', 'g-2.jpg', '(10:57:52 PM, Sun, 01 Nov, 2020)'),
(5, 'Shemontika Bhattacharya', 6, 'Faiad Ul Haque', '', '', 'g-8.jpg', '(11:05:47 PM, Sun, 01 Nov, 2020)'),
(6, 'Shemontika Bhattacharya', 6, 'Faiad Ul Haque', '', '', 'g-8.jpg', '(11:07:25 PM, Sun, 01 Nov, 2020)'),
(7, 'Shemontika Bhattacharya', 6, 'Faiad Ul Haque', '', '', 'g-8.jpg', '(11:08:00 PM, Sun, 01 Nov, 2020)'),
(8, 'Shemontika Bhattacharya', 6, 'Faiad Ul Haque', '', '', 'g-8.jpg', '(11:08:27 PM, Sun, 01 Nov, 2020)'),
(9, 'Shemontika Bhattacharya', 6, 'Faiad Ul Haque', '', '', 'g-8.jpg', '(11:08:42 PM, Sun, 01 Nov, 2020)'),
(13, 'Zeba Fariha', 7, 'WEb', '', 'https://drive.google.com/file/d/1ouYtf5uMnVZQ0IrBC57SFv0bupKCD6jc/preview', 'business-stat.jpg', '(11:12:12 PM, Sun, 01 Nov, 2020)');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_pp` varchar(255) NOT NULL,
  `user_username` varchar(255) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_password` varchar(255) NOT NULL,
  `user_phone` int(11) NOT NULL,
  `user_address` varchar(255) NOT NULL,
  `user_gender` int(11) NOT NULL,
  `user_course` int(11) NOT NULL,
  `user_status` int(11) NOT NULL,
  `user_role` int(11) NOT NULL,
  `mentor_uniqueness` int(11) NOT NULL,
  `user_joined` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_pp`, `user_username`, `user_fullname`, `user_email`, `user_password`, `user_phone`, `user_address`, `user_gender`, `user_course`, `user_status`, `user_role`, `mentor_uniqueness`, `user_joined`) VALUES
(2, '', 'shibli', 'Shibli Anika', 'shibli@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 11, 1, 2, 0, '2020-10-24'),
(3, '', 'moina', 'Moina Rekha', 'moina@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 11, 1, 2, 0, '2020-10-24'),
(4, '', 'arefin', 'Arefinul Islam', 'arefin@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 1, 11, 420, 2, 0, '2020-10-24'),
(5, '', 'shoili', 'Shoili Jahan', 'shoili@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 11, 420, 2, 0, '2020-10-24'),
(6, '', 'billu', 'Billu Ka bhayankor', 'billu@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 1, 11, 1, 2, 0, '2020-10-24'),
(7, '', 'rifat', 'Rifat Sagor', 'rifat@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 1, 11, 1, 2, 0, '2020-10-24'),
(8, '', 'boira', 'Boira Kana', 'boira@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 1, 11, 1, 2, 0, '2020-10-24'),
(9, '', 'malek', 'Malek uddin', 'malek@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 11, 1, 2, 0, '2020-10-24'),
(11, '', 'korim', 'Korim ul alam', 'korim@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 1855414342, '222/1, Malibag', 1, 11, 1, 2, 0, '2020-10-24'),
(12, '', 'shaila', 'Shila Manjil', 'shaila@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 11, 1, 2, 0, '2020-10-24'),
(13, 'indiachinaflags-ians_12.jpg', 'dipto', 'Dipto Alam', 'dipto@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 1, 11, 1, 2, 0, '2020-10-24'),
(15, 'indiachinaflags-ians_12.jpg', 'Rafi', 'Billu Rafi', 'rafi@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 1855414342, '', 1, 11, 1, 2, 0, '2020-10-24'),
(16, '', 'Rafid', 'Rafid ul Islam', 'rafid@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, 'Bujlam na', 1, 12, 1, 2, 0, '2020-10-25'),
(18, '5.jpg', 'anamika', 'Anamika Das', 'anamika@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 11, 1, 2, 0, '2020-10-25'),
(19, '', 'jerin', 'Jerin Malika', 'jerin@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '', 2, 8, 1, 2, 0, '2020-10-25'),
(20, 'g-5.jpg', 'priyo', 'Priyo Hasan', 'priyo@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 1, 11, 1, 2, 0, '2020-10-25'),
(21, '', 'zeba', 'Zeba Fariha', 'zeba@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 7, 1, 2, 0, '2020-10-25'),
(22, '', 'shemontika', 'Shemontika Bhattacharya', 'shemontika@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '222/1, Malibag', 2, 6, 1, 2, 0, '0000-00-00'),
(39, 'g-5.jpg', 'tahsin', 'Tahsin Faruque', 'faruquetahsin@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '', 1, 0, 1, 1, 1, '(12:20:19 AM, Mon, 26 Oct, 2020)'),
(63, '', 'maisha', 'Maisha Islam', 'maisha@gmail.com', '7055eced15538bfb7c07f8a5b28fc5d0', 0, '', 2, 7, 1, 2, 0, '(11:59:02 AM, Sun, 08 Nov, 2020)'),
(64, '', 'rakesh', 'pv', 'rakeshpvofficial@gmail.com', '8843028fefce50a6de50acdf064ded27', 0, '', 1, 7, 1, 2, 0, '(04:34:38 PM, Thu, 22 Apr, 2021)'),
(65, '', 'redwanchowdhury', 'Redwan Chowdhury', 'spta621@gmail.com', '6116afedcb0bc31083935c1c262ff4c9', 0, '', 1, 12, 420, 2, 0, '(01:42:55 AM, Sun, 18 Jul, 2021)'),
(66, '', 'redwanchowdhury', 'Redwan Chowdhury', 'nc1997dot15@gmail.com', '6116afedcb0bc31083935c1c262ff4c9', 0, '', 1, 7, 420, 2, 0, '(01:45:00 AM, Sun, 18 Jul, 2021)'),
(67, '', 'samirahman', 'Sami Rahman', 'samirahman2200@gmail.com', 'cb18f3445228f3a8b823dc2112be50c6', 0, '', 1, 7, 420, 2, 0, '(10:21:28 PM, Mon, 08 Nov, 2021)');

-- --------------------------------------------------------

--
-- Table structure for table `video`
--

CREATE TABLE `video` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  `course` int(11) NOT NULL,
  `details` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `mentor_uniqueness` int(11) NOT NULL,
  `post_date` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `video`
--

INSERT INTO `video` (`id`, `name`, `link`, `course`, `details`, `status`, `mentor_uniqueness`, `post_date`) VALUES
(1, 'PowerPoint animation video', 'https://drive.google.com/file/d/15sXzG9rgTj2yDKG3THNvUfamJa8LRBnc/preview', 11, '', 1, 1, '(03:16:48 PM, Mon, 26 Oct, 2020)'),
(3, 'A random video', 'https://drive.google.com/file/d/1ouYtf5uMnVZQ0IrBC57SFv0bupKCD6jc/preview', 11, 'Loved this video', 1, 1, '(01:27:01 AM, Tue, 27 Oct, 2020)'),
(4, 'A video ', 'https://drive.google.com/file/d/1ouYtf5uMnVZQ0IrBC57SFv0bupKCD6jc/preview', 8, 'This is video details.', 1, 1, '(01:33:20 AM, Tue, 27 Oct, 2020)'),
(6, 'Upwork Interview', 'https://www.youtube.com/embed/UsoOIHddWxU', 8, 'Whats Pp polapain', 420, 1, '(10:28:04 PM, Sun, 01 Nov, 2020)');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `homework`
--
ALTER TABLE `homework`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `video`
--
ALTER TABLE `video`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `homework`
--
ALTER TABLE `homework`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `video`
--
ALTER TABLE `video`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
