<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>

    <!--CODE IS ART-->
    <?php
    $variable = isset($_GET['xun']) ? $_GET['xun'] : "edit";
    if ($variable == "edit") { ?>
        <div class="content-inner chart-cont">


            <div class="row">
                <div class="col-md-12">

                    <!--***** USER INFO *****-->
                    <div class="card form" id="form1">
                        <div class="card-header">
                            <h3><i class="fa fa-user-circle"></i> Edit Your Info</h3>
                        </div>
                        <br>

                        <form method="POST" action="settings.php?xun=update" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="username">Username <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="Username can not be change."></i></label>
                                        <input type="text" class="form-control" style="color:#ff00b5;" id="username" value="<?php echo $_SESSION['username']; ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label for="fullname">Full name</label>
                                        <input type="text" class="form-control" style="color:#ff00b5;" id="fullname" value="<?php echo $_SESSION['fullname']; ?>" name="fullname">
                                    </div>
                                    <div class="form-group">
                                        <label for="email">Email address <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="Email can not be change."></i></label>
                                        <input type="email" class="form-control" id="email" style="color:#ff00b5;" value="<?php echo $_SESSION['email']; ?>" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Gender</label>
                                        <div class="custom_color_radio">
                                            <input name="gender" value="1" type="radio" id="radio_for_male" <?php if ($_SESSION['gender'] == 1) {
                                                                                                                echo "checked";
                                                                                                            }  ?>>
                                            <label for="radio_for_male">Male</label>

                                            <input name="gender" value="2" type="radio" id="radio_for_female" <?php
                                                                                                                if ($_SESSION['gender'] == 2) {
                                                                                                                    echo "checked";
                                                                                                                }  ?>>
                                            <label for="radio_for_female">Female</label>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="d-block">Profile picture (optional) <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="The profile picture has to be in jpg, jpeg, or in png format and must be in less than 200 KB."></i></label>
                                        <input type="file" class="form-control-file" name="image">
                                        <?php
                                        if (empty($_SESSION['image']) and $_SESSION['gender'] == 1) { ?>
                                            <small id="fileHelp" class="form-text text-muted">You can select your profile picture</small>
                                            <img src="img/user/default/male.png" width="30" alt="Profile picture" class="mt-2 unique_img_edit" style="width: 85px;">

                                        <?php } else if (empty($_SESSION['image']) and $_SESSION['gender'] == 2) { ?>
                                            <small id="fileHelp" class="form-text text-muted">You can select your profile picture</small>
                                            <img src="img/user/default/female.png" width="30" alt="Profile picture" class="mt-2 unique_img_edit" style="width: 85px;">

                                        <?php } else if ($_SESSION['image']) { ?>
                                            <img src="img/user/<?php echo $_SESSION['image']; ?>" width="30" alt="Profile picture" class="mt-2 unique_img_edit" style="width: 85px;">
                                        <?php }
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <!--contact-->
                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <h3 style="border-bottom: 1px solid #ddd;">Contact</h3>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone">Phone (optional)</label>
                                        <?php
                                        if (!$_SESSION['phone']) { ?>
                                            <input type="number" class="form-control" id="phone" placeholder="i.e. 01855414342" name="phone">
                                        <?php } else { ?>
                                            <input type="number" class="form-control" id="phone" style="color:#ff00b5;" value="<?php echo "0" . $_SESSION['phone']; ?>" name="phone">
                                        <?php }  ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="address">Address (optional)</label>
                                        <?php
                                        if (!$_SESSION['address']) { ?>
                                            <input type="text" class="form-control" id="address" style="color:#ff00b5;" placeholder="222/1, Malibag, Dhaka" name="address">
                                        <?php } else { ?>
                                            <input type="text" class="form-control" id="address" style="color:#ff00b5;" value="<?php echo $_SESSION['address']; ?>" name="address">
                                        <?php }
                                        ?>
                                    </div>
                                </div>
                            </div>

                            <!--security-->
                            <div class="row mt-4">
                                <div class="col-md-12">
                                    <h3 style="border-bottom: 1px solid #ddd;">Security</h3>
                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone">Password</label>
                                        <input type="password" class="form-control" name="password" placeholder="Enter new password">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="address">Retype password</label>
                                        <input type="password" class="form-control" name="repassword" placeholder="Enter new password again">
                                    </div>
                                </div>
                            </div>

                            <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">

                            <input type="submit" class="btn btn-general" value="Save Changes" style="color:#495057; border:0.7px solid #7ca4c7">

                            <input type="hidden" name="update_user" value="<?php echo $_SESSION['username']; ?>">

                            <div class="row mt-5 pt-3">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="tahsin_eigth_button">
                                            <a href="settings.php?xun=update&xunuserdelete=<?php echo $_SESSION['username']; ?>" class="btn btn-sm tahsin_btn_23"><i class="fas fa-exclamation-triangle"></i> Delete my account</a>
                                        </div><br>
                                    </div>
                                </div>
                            </div>
                    </div>
                    <!--Card-->
                    </form>

                </div>
                <!--Column-->

            </div>
            <!--Row-->
        </div>

    <?php } else if ($variable == "update") {

        //for permanent delete purpose
        if (isset($_GET['xunuserdelete'])) {
            $store_pre_delete = $_GET['xunuserdelete'];
            if ($store_pre_delete) {
                header("location:settings.php?xun=pre_delete");
            }
        }

        //Main Update Content
        if (isset($_POST['update_user'])) {

            $store_update = $_POST['update_user'];

            $fullname = mysqli_real_escape_string($db, $_POST['fullname']);
            $gender = mysqli_real_escape_string($db, $_POST['gender']);
            $phone = mysqli_real_escape_string($db, $_POST['phone']);
            $address = mysqli_real_escape_string($db, $_POST['address']);
            $password = mysqli_real_escape_string($db, $_POST['password']);
            $repassword = mysqli_real_escape_string($db, $_POST['repassword']);

            //Image Validation...
            $image = mysqli_real_escape_string($db, $_FILES['image']['name']);
            $image_tmp = $_FILES['image']['tmp_name'];
            $image_size = $_FILES['image']['size'];
            $formats = array('jpg', 'jpeg', 'png');
            $explode = explode('.', $image);
            $end = end($explode);

            if ($password == $repassword) {

                //with image
                if (!empty($image)) {
                    if ($image_size > 200000) {
                        echo '<span class="text-danger mt-3 ml-3">The profile picture must be less than 200 Kilobytes.</span>';
                    } else if (!in_array($end, $formats)) {
                        echo '<span class="text-danger mt-3 ml-3">The profile picture has to be in jpg, jpeg, or png format.</span>';
                    } else {

                        $limit = 0;
                        $limits = 11;
                        if (strlen($phone) == $limit or strlen($phone) == $limits) {
                            $secure_password = md5(sha1($password));

                            move_uploaded_file($image_tmp, 'img/user/' . $image);

                            $sql = "UPDATE user SET user_fullname = '$fullname', user_password = '$secure_password', user_gender = '$gender', user_pp = '$image', user_phone = '$phone', user_address = '$address' WHERE user_username = '$store_update' ";
                            $query = mysqli_query($db, $sql);
                            if ($query) {
                                echo '<span class="text-success mt-3 ml-3">Successfully updated. </span> <span class = "mt-3 ml-1" style="color:#282525">Changes may take some time to appear everywhere. <a href="settings.php" class="unique_anchor">Click</a> to update again.</span>';
                            } else {
                                die("Operation failed. Please email your problem at contact@codertahsin.com") . mysqli_error($query);
                            }
                        } else {
                            echo '<span class="text-danger mt-3 ml-3">The phone number has to be in 11 digits.</span>';
                        }
                    }
                }
                //without image
                else {
                    $limit = 0;
                    $limits = 11;
                    if (strlen($phone) == $limit || strlen($phone) == $limits) {
                        $secure_password = md5(sha1($password));

                        $sql = "UPDATE user SET user_fullname = '$fullname', user_password = '$secure_password', user_gender = '$gender', user_phone = '$phone', user_address = '$address' WHERE user_username = '$store_update' ";
                        $query = mysqli_query($db, $sql);
                        if ($query) {
                            echo '<span class="text-success mt-3 ml-3">Successfully updated. </span> <span class = "mt-3 ml-1" style="color:#282525">Changes may take some time to appear everywhere. <a href="settings.php" class="unique_anchor">Click</a> to update again.</span>';
                        } else {
                            die("Operation failed. Please email your problem at contact@codertahsin.com") . mysqli_error($query);
                        }
                    } else {
                        echo '<span class="text-danger mt-3 ml-3">The phone number has to be in 11 digits.</span>';
                    }
                }
            } else {
                echo '<span class="text-danger mt-3 ml-3">Password didn\'t match.</span>';
            }
        }
    } else if ($variable == "pre_delete") { ?>

        <body style="background-color: #EEF5F9;">
            <div class="container" style="height:100vh!important">
                <h5 class="pt-4">I <?php echo $_SESSION['fullname']; ?> is permanently deleting my account from the <span style="color:#ff00a2">CT Board</span> platform.</h5>

                <div class="row">
                    <div class="col-md-2 col-">
                        <div class="row mt-3">
                            <div class="col-md-6 col-3">

                                <div class="tahsin_eigth_button">
                                    <a href="settings.php?xun=delete&xunuserdelete=<?php echo $_SESSION['username']; ?>" class="btn btn-sm tahsin_btn_23">Yes</a>
                                </div><br>

                            </div>
                            <div class="col-md-6 col-3">

                                <div class="tahsin_eigth_button">
                                    <a href="dashboard.php" class="btn btn-sm tahsin_btn_23" style="color:#ff00d1!important;">No</a>
                                </div><br>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </body>
    <?php } else if ($variable == "delete") {
        if (isset($_GET['xunuserdelete'])) {
            $store_delete = $_GET['xunuserdelete'];

            //unlink image
            $sql = "SELECT * FROM user WHERE user_username = '$store_delete' ";
            $query = mysqli_query($db, $sql);
            while ($row = mysqli_fetch_assoc($query)) {
                $remove_image = $row['user_pp'];
                unlink("img/user/$remove_image");

                $sql = "DELETE FROM user WHERE user_username = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    session_start();
                    session_unset();
                    session_destroy();
                    header("location:index.php");
                } else {
                    die("Operation failed. Please email your problem at contact@codertahsin.com") . mysqli_error($query);
                }
            }
        }
    }

    ?>


</div>

<?php
include("includes/footer.php")
?>