<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>


    <!--CODE IS ART-->

    <?php
    if ($_SESSION['role'] == 1) {

        $variable = isset($_GET['xun']) ? $_GET['xun'] : "manage";

        if ($variable == "manage") { ?>

            <div class="content-inner chart-cont">
                <h5>Course Management</h5>

                <!--***** CONTENT *****-->
                <div class="row">
                    <table class="table table-hover table-bordered table-responsive">
                        <thead>
                            <tr class="text-white" style="background: #bd7da2!important;">

                                <th>Edit</th>
                                <th>#</th>
                                <th>Course Logo</th>
                                <th>Course Name</th>
                                <th>Course Description</th>
                                <th>Course Status</th>
                                <th>Course Started</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sl = 1;
                            $sql = "SELECT * FROM course ORDER BY course_id DESC";
                            $query = mysqli_query($db, $sql);
                            while ($row = mysqli_fetch_assoc($query)) {
                                $course_id = $row['course_id'];
                                $course_img = $row['course_img'];
                                $course_name = $row['course_name'];
                                $course_desc = $row['course_desc'];
                                $course_status = $row['course_status'];
                                $course_started = $row['course_started'];
                            ?>
                                <tr>
                                    <td>
                                        <ul>
                                            <li style="list-style: none;">
                                                <!-- <a href="#" data-toggle="modal" data-target="#deletecourse<?php echo $course_id; ?>" style="color:#d657ab" class="mr-1" data-toggle="tooltip" data-placement="top" title="Delete this category"> <i class="fas fa-trash-alt"></i></a> -->

                                                <a href="course.php?xun=edit&edit_course=<?php echo $course_id; ?>" style="color:#62bede" data-toggle="tooltip" data-placement="top" title="Edit this category"><i class="fas fa-pen-nib"></i></a>

                                            </li>
                                        </ul>
                                    </td>
                                    <!-- DELETE MODAL START-->
                                    <!-- <div class="modal fade" id="deletecourse<?php echo $course_id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog upor_theke_niche_margin" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">You are deleting <?php echo $course_name; ?> course</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="course.php?xun=delete&delete_course=<?php echo $course_id; ?>" class="btn btn-danger mr-4">Delete</a>
                                                    <button type="" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div> -->
                                    <!-- DELETE MODAL END-->

                                    <td><?php echo $sl; ?></td>
                                    <td>
                                        <?php
                                        if ($course_img) { ?>
                                            <img src="img/course/<?php echo $course_img; ?>" alt="Course logo" width="30" height="20">
                                        <?php } else { ?>
                                            <img src="img/course/default/icon.png" alt="Course logo" width="30">
                                        <?php }
                                        ?>
                                    </td>
                                    <td><?php echo $course_name; ?></td>
                                    <td>
                                        <?php if ($course_desc) {
                                            echo $course_desc;
                                        } else {
                                            echo '<span style="color: #d8a8c3;">N/A</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($course_status == 1) { ?>
                                            <span class="badge badge-pill" style="background: #59ce90;">Running</span>
                                        <?php } else if ($course_status == 420) { ?>
                                            <span class="badge badge-pill" style="background: #d657ab;">Closed</span>
                                        <?php }
                                        ?>
                                    </td>
                                    <td><?php echo $course_started; ?></td>
                                </tr>
                            <?php
                                $sl++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>

        <?php } else if ($variable == "add") { ?>
            <div class="content-inner form-cont">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card form">
                            <div class="card-header">
                                <h3 class="card-title">Add a new course</h3>
                            </div>
                            <br>
                            <form action="course.php?xun=insert" method="POST" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label>Course name</label>
                                            <input type="text" class="form-control" name="course_name">
                                        </div>
                                        <div class="form-group">
                                            <label>Course details (optional)</label>
                                            <textarea class="form-control" rows="3" style="border-radius: 0;" name="course_desc"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label>Course status</label>
                                            <select class="form-control" name="course_status">
                                                <option value="1">Running</option>
                                                <option value="420">Closed</option>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label class="d-block">Course logo (optional) <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="The logo has to be in jpg, jpeg, or in png format and must be in less than 200 KB."></i></label>
                                            <input type="file" class="form-control-file" name="course_img">
                                            <small id="fileHelp" class="form-text text-muted">You can select a logo for this course.</small>
                                        </div>
                                    </div>
                                </div>
                                <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">
                                <input type="submit" class="btn btn-general " value="Add" style="color:#495057; border:0.7px solid #7ca4c7" name="submit">
                            </form>
                        </div>

                    </div>
                </div>
            </div>

            <?php } else if ($variable == "insert") {

            date_default_timezone_set("Asia/Dhaka");
            $bd_date = date("(h:i:s A, D, d M, Y)");

            if (isset($_POST['submit'])) {
                $course_name = mysqli_real_escape_string($db, $_POST['course_name']);
                $course_desc = mysqli_real_escape_string($db, $_POST['course_desc']);
                $course_status = mysqli_real_escape_string($db, $_POST['course_status']);

                // for image validation
                $course_img_formats = array('jpg', 'png', 'jpeg');
                $course_img = mysqli_real_escape_string($db, $_FILES['course_img']['name']);
                $course_img_size = $_FILES['course_img']['size'];
                $course_img_tmp = $_FILES['course_img']['tmp_name'];
                $explode = explode(".", $course_img);
                $end = end($explode);

                if (!empty($course_name)) {

                    if (!empty($course_img)) {
                        if ($course_img_size > 200000) {
                            echo '<span class="text-danger mt-3 ml-3">The logo has to be smaller than 200 Kilobyte. <a href="course.php?xun=add">Click</a> to return.</span>';
                        } else if (!in_array($end, $course_img_formats)) {
                            echo '<span class="text-danger mt-3 ml-3">The logo has to be in jpg, jpeg, or png format. <a href="course.php?xun=add">Click</a> to return.</span>';
                        } else {
                            move_uploaded_file($course_img_tmp, 'img/course/' . $course_img);

                            $sql = "INSERT INTO course (course_img, course_name, course_desc, course_status, course_started) VALUES ('$course_img', '$course_name','$course_desc', '$course_status', '$bd_date' )";
                            $query = mysqli_query($db, $sql);
                            if ($query) {
                                echo '<span class="text-success mt-3 ml-3">Course added successfully. <a href="course.php?xun=add" class="unique_anchor">Click</a> to add another. <a href="course.php?xun=manage" class="unique_anchor">Click</a> to see all courses.</span>';
                            } else {
                                die("Operation failed" . mysqli_error($db));
                            }
                        }
                    } else {
                        $sql = "INSERT INTO course (course_name, course_desc, course_status, course_started) VALUES ('$course_name', '$course_desc', '$course_status', '$bd_date' )";
                        $query = mysqli_query($db, $sql);
                        if ($query) {
                            echo '<span class="text-success mt-3 ml-3">Course added successfully. <a href="course.php?xun=add" class="unique_anchor">Click</a> to add another. <a href="course.php?xun=manage" class="unique_anchor">Click</a> to see all courses.</span>';
                        } else {
                            die("Operation failed" . mysqli_error($db));
                        }
                    }
                } else {
                    echo '<span class="text-danger mt-3 ml-3">Course name field was empty. <a href="course.php?xun=add">Click</a> to return.</span>';
                }
            }
        } else if ($variable == "edit") {
            if (isset($_GET['edit_course'])) {
                $store_edit_course = $_GET['edit_course'];

                $sql = "SELECT * FROM course WHERE course_id = '$store_edit_course' ";
                $query = mysqli_query($db, $sql);
                while ($row = mysqli_fetch_assoc($query)) {
                    $course_id = $row['course_id'];
                    $course_name = $row['course_name'];
                    $course_desc = $row['course_desc'];
                    $course_status = $row['course_status'];
                    $course_img = $row['course_img'];
            ?>
                    <div class="content-inner form-cont">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card form">
                                    <div class="card-header">
                                        <h3 class="card-title">Update <?php echo $course_name; ?> course</h3>
                                    </div>
                                    <br>
                                    <form action="course.php?xun=update" method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <div class="form-group">
                                                    <label>Course name</label>
                                                    <input type="text" class="form-control" value="<?php echo $course_name; ?>" style="color:#ff00b5;" name="course_name">
                                                </div>
                                                <div class="form-group">
                                                    <label>Course details (optional)</label>
                                                    <textarea class="form-control" rows="3" style="border-radius: 0;color:#ff00b5;" name="course_desc"><?php echo $course_desc; ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label>Course status</label>
                                                    <select class="form-control" style="color:#ff00b5;" name="course_status">
                                                        <option value="1" <?php if ($course_status == 1) {
                                                                                echo "selected";
                                                                            } ?>>Running</option>
                                                        <option value="420" <?php if ($course_status == 420) {
                                                                                echo "selected";
                                                                            } ?>>Closed</option>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label class="d-block">Course logo (optional) <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="The logo has to be in jpg, jpeg, or in png format and must be in less than 200 KB."></i></label>
                                                    <input type="file" class="form-control-file" name="course_img">
                                                    <?php
                                                    if (empty($course_img)) { ?>
                                                        <img src="img/course/default/icon.png" width="30" alt="Course logo" class="mt-2 unique_img_edit">
                                                    <?php } else { ?>
                                                        <img src="img/course/<?php echo $course_img; ?>" width="30" alt="Course logo" class="mt-2 unique_img_edit">
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">
                                        <input type="submit" class="btn btn-general" value="Save Changes" style="color:#495057; border:0.7px solid #7ca4c7">
                                        <input type="hidden" name="submit_edit" value="<?php echo $course_id; ?>">
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
    <?php }
            }
        } else if ($variable == "update") {
            if (isset($_POST['submit_edit'])) {
                $store_update = $_POST['submit_edit'];

                $course_name = mysqli_real_escape_string($db, $_POST['course_name']);
                $course_desc = mysqli_real_escape_string($db, $_POST['course_desc']);
                $course_status = mysqli_real_escape_string($db, $_POST['course_status']);

                //image validation...
                $formats = array('jpg', 'jpeg', 'png');
                $course_img = mysqli_real_escape_string($db, $_FILES['course_img']['name']);
                $course_img_tmp = $_FILES['course_img']['tmp_name'];
                $course_img_size = $_FILES['course_img']['size'];
                $explode = explode('.', $course_img);
                $end = end($explode);

                if (!empty($course_img)) {
                    if ($course_img_size > 200000) {
                        echo '<span class="text-danger mt-3 ml-3">The logo has to be smaller than 200 Kilobytes. <a href="course.php?xun=manage" class="unique_anchor">Click</a> to go back.</span>';
                    } else if (!in_array($end, $formats)) {
                        echo '<span class="text-danger mt-3 ml-3">The logo has to be in jpg, jpeg, or png format. <a href="course.php?xun=manage" class="unique_anchor">Click</a> to go back.</span>';
                    } else {
                        //to unlink image 
                        $sql = "SELECT * FROM course WHERE course_id = '$store_update' ";
                        $query = mysqli_query($db, $sql);
                        while ($row = mysqli_fetch_assoc($query)) {
                            $remove_img = $row['course_img'];
                        }
                        unlink("img/course/$remove_img");
                        /////
                        move_uploaded_file($course_img_tmp, 'img/course/' . $course_img);
                        $sql = "UPDATE course SET course_name = '$course_name', course_desc = '$course_desc', course_status = '$course_status', course_img = '$course_img' WHERE course_id = '$store_update' ";
                        $query = mysqli_query($db, $sql);
                        if ($query) {
                            echo '<span class="text-success mt-3 ml-3">Successfully updated. <a href="course.php?xun=manage" class="unique_anchor">Click</a> to see all courses.</span>';
                        } else {
                            die("Operation Failed" . mysqli_error($db));
                        }
                    }
                } else {
                    $sql = "UPDATE course SET course_name = '$course_name', course_desc = '$course_desc', course_status = '$course_status' WHERE course_id = '$store_update' ";
                    $query = mysqli_query($db, $sql);
                    if ($query) {
                        echo '<span class="text-success mt-3 ml-3">Successfully updated. <a href="course.php?xun=manage" class="unique_anchor">Click</a> to see all courses.</span>';
                    } else {
                        die("Operation Failed" . mysqli_error($db));
                    }
                }
            }
        } else if ($variable == "delete") {
            if (isset($_GET['delete_course'])) {
                $store_delete = $_GET['delete_course'];

                $sql = "DELETE FROM course WHERE course_id = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    header("location:course.php?xun=manage");
                } else {
                    die("Operation failed" . mysqli_error($query));
                }
            }
        }
    } //Session role 1 na hole mara... 
    ?>




</div>

<?php
include("includes/footer.php");
?>