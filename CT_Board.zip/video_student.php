<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>

    <!--CODE IS ART-->

    <div class="container" style="background: #EEF5F9; padding-top: 20px; padding-bottom: 35px;">

        <div class="row">

            <?php

            $session_course = $_SESSION['course'];
            $mentor_uniqueness = $_SESSION['mentor_uniqueness'];

            $sql = "SELECT * FROM video WHERE status = 1 AND course = '$session_course' || mentor_uniqueness = $mentor_uniqueness ORDER BY id DESC";
            $query = mysqli_query($db, $sql);
            while ($row = mysqli_fetch_assoc($query)) {
                $id = $row['id'];
                $name = $row['name'];
                $link = $row['link'];
                $course = $row['course'];
                $details = $row['details'];
                $status = $row['status'];
                $mentor_uniqueness = $row['mentor_uniqueness'];
                $post_date = $row['post_date'];
            ?>

                <div class="col-xl-6 col-12 pl-0 pr-0 py-1 ">
                    <div class="card-body ForHover">
                        <div class="iframe-container">
                            <iframe class="border border-danger iframe IamNoTopMargin" width="560" src="<?php echo $link; ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                            </iframe>
                        </div>

                        <div class="card-body">
                            <h3 class="card-text" style="color: #ff00ac"><?php echo $name; ?></h3>
                            <p class="card-text"><?php echo $post_date; ?></p>

                            <?php
                            if (!empty($details)) { ?>
                                <div class="col-md-12 tenth-button pl-0">
                                    <a href="video_student_details.php?get_details=<?php echo $id; ?>" target="_blank" class="btn btn-lg red">SEE MORE
                                    </a>
                                </div>
                            <?php }
                            ?>

                        </div>
                    </div>
                </div>
                <!--Col-End-->
            <?php } ?>

        </div>


    </div>
    <!--Conatainer-->


</div>
<!--page content-->

<?php
include("includes/footer.php")
?>