<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>


    <!--CODE IS ART-->

    <?php
    if ($_SESSION['role'] == 1) {

        $variable = isset($_GET['xun']) ? $_GET['xun'] : "manage";

        if ($variable == "manage") { ?>

            <div class="content-inner chart-cont">
                <h5>Homework Management</h5>
                <!--***** CONTENT *****-->
                <div class="row">
                    <table class="table table-hover table-bordered table-responsive">
                        <thead>
                            <tr class="text-white" style="background: #bd7da2!important;">

                                <th>Action</th>
                                <th>#</th>
                                <th>Submitted By</th>
                                <th>Course Enrolled</th>
                                <th>Homework Name</th>
                                <th>Description</th>
                                <th>Homework File</th>
                                <!-- <th>Submitted By</th>
                            <th>Course Enrolled</th> -->
                                <th>Additional Link</th>
                                <th>Time</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sl = 1;
                            $sql = "SELECT * FROM homework ORDER BY id DESC";
                            $query = mysqli_query($db, $sql);
                            while ($row = mysqli_fetch_assoc($query)) {
                                $id = $row['id'];
                                $submitted_by = $row['submitted_by'];
                                $course_enrolled = $row['course_enrolled'];
                                $name = $row['name'];
                                $details = $row['details'];
                                $file = $row['file'];
                                $link = $row['link'];
                                $submit_date = $row['submit_date'];
                            ?>
                                <tr>
                                    <td>
                                        <ul>
                                            <li style="list-style: none;">
                                                <a href="#" data-toggle="modal" data-target="#deletehomework<?php echo $id; ?>" style="color:#d657ab" class="mr-1" data-toggle="tooltip" data-placement="top" title="Delete this category"> <i class="fas fa-trash-alt"></i></a>
                                            </li>
                                        </ul>
                                    </td>
                                    <!-- DELETE MODAL START-->
                                    <div class="modal fade" id="deletehomework<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog upor_theke_niche_margin" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">You are deleting <?php echo $name; ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="homework_mentor.php?xun=delete&delete_hw=<?php echo $id; ?>" class="btn btn-danger mr-4">Delete</a>
                                                    <button type="" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- DELETE MODAL END-->

                                    <td><?php echo $sl; ?></td>
                                    <td><?php echo $submitted_by ?></td>
                                    <td>
                                        <?php
                                        $sql = "SELECT * FROM course WHERE course_id = '$course_enrolled' ";
                                        $course_query = mysqli_query($db, $sql);
                                        while ($row = mysqli_fetch_assoc($course_query)) {
                                            $course_name = $row['course_name'];
                                        }
                                        echo $course_name;

                                        ?>
                                    </td>
                                    <td><?php echo $name; ?></td>
                                    <td>
                                        <?php if ($details) {
                                            echo $details;
                                        } else {
                                            echo '<span style="color: #d8a8c3;">N/A</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <a href="img/homework/<?php echo $file; ?>" target="_blank" style="color:#ff00db">View</a>
                                    </td>
                                    <td>
                                        <?php if ($link) { ?>
                                            <a href="<?php echo $link; ?>" target="_blank" style="color:#65bdd4;">Link</a>
                                        <?php } else {
                                            echo '<span style="color: #d8a8c3;">N/A</span>';
                                        }
                                        ?>
                                    </td>
                                    <td><?php echo $submit_date; ?></td>
                                </tr>
                            <?php
                                $sl++;
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>


    <?php  } else if ($variable == "delete") {
            if (isset($_GET['delete_hw'])) {
                $store_delete = $_GET['delete_hw'];

                $sql = "SELECT * FROM homework WHERE id = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                while ($row = mysqli_fetch_assoc($query)) {
                    $unlink =  $row['file'];
                }
                unlink("img/homework/$unlink");

                $sql = "DELETE FROM homework WHERE id = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    header("location:homework_mentor.php");
                } else {
                    die("Operation failed. Something happened wrong." . mysqli_error($query));
                }
            }
        }
    } //Session role 1 na hole mara... 
    ?>




</div>

<?php
include("includes/footer.php");
?>