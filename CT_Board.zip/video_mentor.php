<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>

    <!--CODE IS ART-->

    <?php

    if ($_SESSION['role'] == 1) {


        $variable = isset($_GET['xun']) ? $_GET['xun'] : "manage";

        if ($variable == "manage") { ?>

            <div class="content-inner">
                <h5>Video Management</h5>

                <!--***** CONTENT *****-->
                <div class="row">
                    <table class="table table-hover table-bordered table-responsive">
                        <thead>
                            <tr class="text-white" style="background: #b584bf!important">
                                <th>Action</th>
                                <th>#</th>
                                <th>Name</th>
                                <th>Video</th>
                                <th>Course</th>
                                <th>Details</th>
                                <th>Status</th>
                                <th>Uploaded</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sl = 1;
                            $sql = "SELECT * FROM video ORDER BY id DESC";
                            $query = mysqli_query($db, $sql);
                            while ($row = mysqli_fetch_assoc($query)) {
                                $id = $row['id'];
                                $name = $row['name'];
                                $link = $row['link'];
                                $course = $row['course'];
                                $details = $row['details'];
                                $status = $row['status'];
                                $post_date = $row['post_date'];

                            ?>
                                <tr>
                                    <td>
                                        <ul>
                                            <li style="list-style: none;">
                                                <a href="#" data-toggle="modal" data-target="#deletevideo<?php echo $id; ?>" class="mr-1" style="color:#d657ab" data-toggle="tooltip" data-placement="top" title="Delete the information of this student"> <i class="fas fa-trash-alt"></i></a>


                                                <a href="video_mentor.php?xun=edit&edit_video=<?php echo $id; ?>" style="color:#62bede" data-toggle="tooltip" data-placement="top" title="Click to update the information of this student"><i class="fas fa-pen-nib"></i></a>
                                            </li>
                                        </ul>
                                    </td>
                                    <!-- DELETE MODAL START-->
                                    <div class="modal fade" id="deletevideo<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog upor_theke_niche_margin" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">You are deleting <?php echo $name . "'s"; ?> video</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="video_mentor.php?xun=delete&delete_video=<?php echo $id; ?>" class="btn mr-4" style="background-color:#d657ab; color:#fff;">Delete</a>
                                                    <button type="" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- DELETE MODAL END-->

                                    <td><?php echo $sl; ?></td>
                                    <td><?php echo $name; ?></td>
                                    <td><a href="<?php echo $link; ?>" target="_blank" style="color: #ba03ff">View</a></td>
                                    <td>
                                        <?php
                                        $sql = "SELECT * FROM course WHERE course_id = '$course'";
                                        $course_query = mysqli_query($db, $sql);
                                        while ($row = mysqli_fetch_assoc($course_query)) {
                                            $course_name = $row['course_name'];
                                        }
                                        echo $course_name;

                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if (empty($details)) {
                                            echo '<span style="color: #d8a8c3;">N/A</span>';
                                        } else {

                                            echo substr($details, 0, 7) . "..."; ?>
                                            <a href="video_student_details.php?get_details=<?php echo $id; ?>" style="color: #ba03ff">more</a>
                                        <?php }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($status == 1) { ?>
                                            <span class="badge badge-pill" style="background: #59ce90;">Live</span>
                                        <?php } else if ($status == 420) { ?>
                                            <span class="badge badge-pill" style="background: #d657ab;">Hidden</span>
                                        <?php }
                                        ?>
                                    </td>
                                    <td>
                                        <?php echo $post_date; ?>
                                    </td>
                                </tr>
                            <?php
                                $sl++;
                            }

                            ?>
                        </tbody>

                    </table>
                </div>

            </div>

        <?php } else if ($variable == "add") { ?>
            <div class="content-inner form-cont">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card form">
                            <div class="card-header">
                                <h3 class="card-title">Add a new video</h3>
                            </div>
                            <br>
                            <form action="video_mentor.php?xun=insert" method="POST">
                                <div class="row">
                                    <div class="col-md-7">
                                        <div class="form-group">
                                            <label>Video name</label>
                                            <input type="text" class="form-control" placeholder="GD-2 (1)" name="name">
                                        </div>
                                        <div class="form-group">
                                            <label>Video for (Select a course)</label>
                                            <select class="form-control" name="course">
                                                <?php
                                                $sql = "SELECT * FROM course WHERE course_status = 1";
                                                $query = mysqli_query($db, $sql);
                                                $count = mysqli_num_rows($query);
                                                if ($count == 0) { ?>
                                                    <option value="420">No course is running now</option>
                                                    <?php } else {
                                                    $sql = "SELECT * FROM course WHERE course_status = 1 ORDER BY course_id DESC";
                                                    $query = mysqli_query($db, $sql);
                                                    while ($row = mysqli_fetch_assoc($query)) {
                                                        $course_id = $row['course_id'];
                                                        $course_name = $row['course_name'];
                                                    ?>
                                                        <option value="<?php echo $course_id; ?>"><?php echo $course_name; ?></option>
                                                <?php }
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Video link <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="You will give the only iframe source link. For example src = (https://drive.google.com/tahsinfaruquesayscodeisart) Here, you will only put the src link as shown into the bracket. "></i>
                                            </label>
                                            <input type="url" class="form-control" placeholder="https://drive.google.com/file/d/1ouYtf5uMnVZQ0IrBC57SFv0bupKCD6jc/preview" name="link">
                                        </div>
                                        <div class="form-group">
                                            <label>Video details (optional)</label>
                                            <textarea class="form-control" rows="3" style="border-radius: 0;" name="details"></textarea>
                                            <small id="fileHelp" class="form-text text-muted">You can also give a link into href = " " using an anchor tag.</small>
                                        </div>
                                        <div class="form-group">
                                            <label>Video status</label>
                                            <select class="form-control" name="status">
                                                <option value="1">Show</option>
                                                <option value="420">Hide</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">
                                <input type="submit" class="btn btn-general " value="Add" style="color:#495057; border:0.7px solid #7ca4c7" name="submit">
                            </form>
                        </div>

                    </div>
                </div>
            </div>
            <?php } else if ($variable == "insert") {

            date_default_timezone_set('Asia/Dhaka');
            $bd_date = date("(h:i:s A, D, d M, Y)");

            if (isset($_POST['submit'])) {

                $name = $_POST['name'];
                $link = $_POST['link'];
                $details = $_POST['details'];
                $course = $_POST['course'];
                $status = $_POST['status'];

                if (!empty($name)) {
                    if (!empty($link)) {
                        if (!empty($status)) {
                            if ($course == 420) {
                                echo '<span class="text-danger mt-3 ml-3">No course is currently running. <a href="video_mentor.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                            } else {
                                $sql = "INSERT INTO video (name, link, course, details, status, mentor_uniqueness, post_date) VALUES ('$name', '$link', '$course', '$details', '$status', 1, '$bd_date') ";
                                $query = mysqli_query($db, $sql);
                                if ($query) {
                                    echo '<span class="text-success mt-3 ml-3">Video uploaded successfully. <a href="video_mentor.php?xun=add" class="unique_anchor">Click</a> to add a new video. <a href="video_mentor.php?xun=manage" class="unique_anchor">Click</a> to see all videos.</span>';
                                } else {
                                    die("Operation failed" . mysqli_error($query));
                                }
                            }
                        } else {
                            echo '<span class="text-danger mt-3 ml-3">Status field was empty. <a href="video_mentor.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                        }
                    } else {
                        echo '<span class="text-danger mt-3 ml-3">Link field was empty. <a href="video_mentor.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                    }
                } else {
                    echo '<span class="text-danger mt-3 ml-3">Name field was empty. <a href="video_mentor.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                }
            }
        } else if ($variable == "edit") {
            if (isset($_GET['edit_video'])) {
                $store_edit = $_GET['edit_video'];

                $sql = "SELECT * FROM video WHERE id = '$store_edit' ";
                $query = mysqli_query($db, $sql);
                while ($row = mysqli_fetch_assoc($query)) {
                    $name = $row['name'];
                    $link = $row['link'];
                    $course = $row['course'];
                    $details = $row['details'];
                    $status = $row['status'];
            ?>

                    <div class="content-inner form-cont">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card form">
                                    <div class="card-header">
                                        <h3 class="card-title">Add a new video</h3>
                                    </div>
                                    <br>
                                    <form action="video_mentor.php?xun=update" method="POST">
                                        <div class="row">
                                            <div class="col-md-7">
                                                <div class="form-group">
                                                    <label>Video name</label>
                                                    <input type="text" style="color: #ff00b5;" class="form-control" value="<?php echo $name; ?>" name="name">
                                                </div>
                                                <div class="form-group">
                                                    <label>Video for</label>
                                                    <select class="form-control" name="course" style="color: #ff00b5;">
                                                        <?php
                                                        $sql = "SELECT * FROM course WHERE course_status = 1";
                                                        $new_query = mysqli_query($db, $sql);
                                                        $count = mysqli_num_rows($new_query);
                                                        if ($count == 0) { ?>
                                                            <option value="420">No course is running now</option>
                                                            <?php } else {
                                                            $sql = "SELECT * FROM course WHERE course_status = 1";
                                                            $again_new_query = mysqli_query($db, $sql);
                                                            while ($row = mysqli_fetch_assoc($again_new_query)) {
                                                                $course_id = $row['course_id'];
                                                                $course_name = $row['course_name'];
                                                            ?>
                                                                <option value="<?php echo $course_id; ?>"><?php echo $course_name; ?></option>
                                                        <?php }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Video link <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="" data-original-title="You will give the only iframe source link. For example src = (https://drive.google.com/tahsinfaruquesayscodeisart) Here, you will only put the src link as shown into the bracket. "></i>
                                                    </label>
                                                    <input type="url" class="form-control" style="color: #ff00b5;" value="<?php echo $link; ?>" name="link">
                                                </div>
                                                <div class="form-group">
                                                    <label>Video details (optional)</label>
                                                    <textarea class="form-control" rows="3" style="border-radius: 0;color: #ff00b5;" name="details"><?php echo $details; ?></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label>Video status</label>
                                                    <select class="form-control" style="color: #ff00b5;" name="status">
                                                        <option value="1" <?php if ($status == 1) {
                                                                                echo "selected";
                                                                            }
                                                                            ?>>Show</option>
                                                        <option value="420" <?php if ($status == 420) {
                                                                                echo "selected";
                                                                            } ?>>Hide</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">
                                        <input type="submit" class="btn btn-general " value="Save changes" style="color:#495057; border:0.7px solid #7ca4c7">
                                        <input type="hidden" value="<?php echo $store_edit; ?>" name="submit">
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>

    <?php } //loop end
            }
        } else if ($variable == "update") {
            if (isset($_POST['submit'])) {
                $store_update = $_POST['submit'];

                $name = $_POST['name'];
                $link = $_POST['link'];
                $course = $_POST['course'];
                $details = $_POST['details'];
                $status = $_POST['status'];

                if ($course == 420) {
                    $sql = "UPDATE video SET name ='$name', link ='$link', details ='$details', status ='$status' WHERE id = '$store_update' ";
                    $query = mysqli_query($db, $sql);
                    if ($query) {
                        echo '<span class="text-success mt-3 ml-3">Successfully updated. <a href="video_mentor.php?xun=manage" class="unique_anchor">Click</a> to see all videos.</span>';
                    } else {
                        die("Operation failed" . mysqli_error($query));
                    }
                } else {
                    $sql = "UPDATE video SET name ='$name', link ='$link', course ='$course', details ='$details', status ='$status' WHERE id = '$store_update' ";
                    $query = mysqli_query($db, $sql);
                    if ($query) {
                        echo '<span class="text-success mt-3 ml-3">Successfully updated. <a href="video_mentor.php?xun=manage" class="unique_anchor">Click</a> to see all videos.</span>';
                    } else {
                        die("Operation failed" . mysqli_error($query));
                    }
                }
            }
        } else if ($variable == "delete") {
            if (isset($_GET['delete_video'])) {
                $store_delete = $_GET['delete_video'];

                $sql = "DELETE FROM video WHERE id = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    echo '<span class="text-success mt-3 ml-3">Successfully deleted. <a href="video_mentor.php?xun=add" class="unique_anchor">Click</a> to add a new video. <a href="video_mentor.php?xun=manage" class="unique_anchor">Click</a> to see all videos.</span>';
                } else {
                    die("Operation failed" . mysqli_error($query));
                }
            }
        }
    } //Session role 1 na hole mara... 
    ?>


</div>

<?php
include("includes/footer.php")
?>