<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>

    <!--CODE IS ART-->
    <?php
    if (isset($_GET['get_details'])) {
        $store = $_GET['get_details'];

        $sql = "SELECT * FROM video WHERE id = '$store' ";
        $query = mysqli_query($db, $sql);
        while ($row = mysqli_fetch_assoc($query)) {
            $id = $row['id'];
            $name = $row['name'];
            $link = $row['link'];
            $course = $row['course'];
            $details = $row['details'];
            $status = $row['status'];
            $post_date = $row['post_date'];
    ?>
            <div class="container" style="background: #EEF5F9;">
                <div class="row">
                    <div class="col-md-6 col-12">
                        <h3 class="responsive_h1" style="margin-top: 20px;">Details of <?php echo $name; ?>'s video</h3>
                        <h6 style="margin-top: 21px;"><?php echo $details; ?></h6>
                    </div>
                </div>
            </div>
    <?php }
    }
    ?>

</div>

<?php
include("includes/footer.php")
?>