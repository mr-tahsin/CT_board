<?php
require("includes/db.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Signup &mdash; CT Board</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="A complete workable dynamic learning management system named CT Board developed by Tahsin Faruque">
    <meta property="og:image" content="img/logo.png">
    <meta name="keywords" content="html, css, javascript, jquery, php, mysql, coder tahsin, mahi tahsin,web developer; website builder; website designer; ecommerce website; codertahsin.com; Tahsin Faruque; best web developer in BD; bangladesh; ecommerce business; best motivator; Dhaka; Shikhbe Shobai; ForidRony; landing page; best programmer in bd; best programmer and web developer in fiverr; best programmer and web developer in upwork; best programmer and web developer in freelancer; best programmer and web developer in payperhour; weebly best website builder; shopify best website builder; squarespace best website builder; wordpress; best wordpress developer in Bangladesh; Pakistan; India; astra developer; avada developer; java; best php web developer, newsportal site,web design, SEO">
    <meta name="author" content="Tahsin Faruque">
    <!--===============================================================================================-->
    <link rel="icon" href="img/icon.ico" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/fonts/iconic/css/material-design-iconic-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/animsition/css/animsition.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/daterangepicker/daterangepicker.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/css/util.css">
    <link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/css/main.css">
    <!--===============================================================================================-->

    <!--Tahsin's Custom CSS-->
    <link rel="stylesheet" href="LOGIN - SIGNUP/css/Tahsin_Faruque.css">
    <link rel="stylesheet" href="css/tahsin_faruque.css">
</head>

<body>

    <div class="limiter">
        <div class="container-login100" style="background-image: url('LOGIN - SIGNUP/images/bg-01.jpg');">

            <?php

            date_default_timezone_set('Asia/Dhaka');
            $bd_date = date("(h:i:s A, D, d M, Y)");

            $success_alert = "";
            $failure_alert = "";
            $inactive_course = "";

            if (isset($_POST['register'])) {

                $username = mysqli_real_escape_string($db, $_POST['username']);
                $fullname = mysqli_real_escape_string($db, $_POST['fullname']);
                $email = mysqli_real_escape_string($db, $_POST['email']);
                $gender = mysqli_real_escape_string($db, $_POST['gender']);
                $course = mysqli_real_escape_string($db, $_POST['course']);
                $password = mysqli_real_escape_string($db, $_POST['password']);
                $repassword = mysqli_real_escape_string($db, $_POST['repassword']);


                if ($password == $repassword) {
                    $secure_pass = md5(sha1($password));
                    //Duplicate username alert
                    $sql = "SELECT * FROM user WHERE user_username = '$username' && user_email = '$email' ";
                    $pass_query = mysqli_query($db, $sql);
                    $count = mysqli_num_rows($pass_query);
                    if ($count > 0) {
                        $failure_alert = '<div class="custom_alert" style = "color:#ff0090!important" >Username already taken. Please try another one.</div>';
                    } else {
                        //Duplicate email alert
                        $sql = "SELECT * FROM user WHERE user_email = '$email' ";
                        $query = mysqli_query($db, $sql);
                        $count = mysqli_num_rows($query);
                        if ($count > 0) {
                            $failure_alert = '<div class="custom_alert" style = "color:#ff0090!important" >Email has been registered. Please give another email.</div>';
                        } else if ($course != 420) {
                            //snippets in details...
                            if (preg_match("/[^a-zA-Z0-9]/", $username)) {
                                $failure_alert = '<div class="custom_alert" style = "color:#ff0090!important; font-weight:900" >Please do not use any space or any special character like "$", "@", "+", ".", "*", etc. to write your username.</div>';
                            } else {

                                //CODE IS ART...
                                $sql = "INSERT INTO user (user_username, user_fullname, user_email, user_gender, user_course, user_password, user_status, user_role, user_joined) VALUES ('$username','$fullname','$email','$gender','$course','$secure_pass', 420, 2, '$bd_date') ";
                                $query = mysqli_query($db, $sql);
                                if ($query) {
                                    $success_alert = '<div class="custom_alert">You have been registered successfully!</div>';
                                } else {
                                    die("Operation failed. Something went wrong. Please do email regarding your problem at contact@codertahsin.com") . mysqli_error($query);
                                }
                            }
                        } else {
                            $inactive_course = '<span class="text-danger custom_alert">Sorry, no course is running now. <a href="https://facebook.com/xun.bd" class="unique_anchor">Click</a> to stay updated. <a href="#" class="unlink_anchor">Have a XunFul day :)</a></span>';
                        }
                    }
                } else {
                    $failure_alert = '<div class="custom_alert" style = "color:#ff0090!important" >Password didn\'t match</div>';
                }
            }
            ?>


            <div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">
                <form class="login100-form validate-form" method="POST">
                    <span class="login100-form-title p-b-49 ">
                        CT Board Register
                    </span>

                    <?php
                    echo $success_alert;
                    echo $failure_alert;
                    echo $inactive_course;
                    ?>

                    <div class="wrap-input100 validate-input m-b-23" data-validate="Username is required">
                        <span class="label-input100">Username</span>
                        <input class="input100" type="text" name="username" placeholder="Type a username">
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-23" data-validate="Fullname is required">
                        <span class="label-input100">Full name</span>
                        <input class="input100" type="text" name="fullname" placeholder="Type your fullname">
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-23" data-validate="Email is required">
                        <span class="label-input100">Email</span>
                        <input class="input100" type="email" name="email" placeholder="Type an email">
                        <span class="focus-input100" data-symbol="&#xf206;"></span>
                    </div>

                    <div class="form-group m-b-23">
                        <label>Gender</label>
                        <div class="custom_color_radio">
                            <input name="gender" value="1" type="radio" id="radio_for_male" required>
                            <label for="radio_for_male" style="font-family: Poppins-Medium; color:#333333;">Male</label>

                            <input name="gender" value="2" type="radio" id="radio_for_female" required>
                            <label for="radio_for_female" style="font-family: Poppins-Medium; color:#333333;">Female</label>
                        </div>
                    </div>

                    <div class="form-group m-b-23">
                        <label>Select a course</label>
                        <?php
                        $sql = "SELECT * FROM course WHERE course_status = 1";
                        $query = mysqli_query($db, $sql);
                        $count = mysqli_num_rows($query);
                        if ($count == 0) { ?>
                            <select class="form-control" style="color:#ff00b5;font-family: Poppins-Medium;padding-top: 4px;" name="course">
                                <option value="420">Sorry, no course is running now</option>
                            </select>
                        <?php } else { ?>

                            <select class="form-control" style="font-family: Poppins-Medium;padding-top: 4px;" name="course">

                                <?php $sql = "SELECT * FROM course WHERE course_status = 1 ORDER BY course_id DESC";
                                $query = mysqli_query($db, $sql);
                                while ($row = mysqli_fetch_assoc($query)) {
                                    $course_name = $row['course_name'];
                                    $course_id = $row['course_id'];
                                ?>
                                    <option value="<?php echo $course_id ?>"><?php echo $course_name ?></option>
                                <?php } ?>
                            </select>
                        <?php
                        } ?>
                    </div>

                    <div class="wrap-input100 validate-input m-b-23" data-validate="Password is required">
                        <span class="label-input100">Password</span>
                        <input class="input100" type="password" name="password" placeholder="Type a password">
                        <span class="focus-input100" data-symbol="&#xf190;"></span>
                    </div>

                    <div class="wrap-input100 validate-input m-b-23" data-validate="Repassword is required">
                        <span class="label-input100">Repassword</span>
                        <input class="input100" type="password" name="repassword" placeholder="Retype your password">
                        <span class="focus-input100" data-symbol="&#xf190;"></span>
                    </div>

                    <div class="text-right p-t-8 p-b-31">
                        <!-- <a href="#">
							Forgot password?
						</a> -->
                    </div>

                    <div class="container-login100-form-btn">
                        <div class="wrap-login100-form-btn">
                            <div class="login100-form-bgbtn"></div>
                            <button class="login100-form-btn">
                                Sign Up
                            </button>
                            <input type="hidden" name="register">
                        </div>
                    </div>

                    <div class="flex-col-c p-t-30">
                        <a href="index.php" class="txt2 unique_anchor" style="text-transform: none;">
                            <span style="color:#333333;cursor:auto;">Already have an account?</span> Go to login
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- <div id="dropDownSelect1"></div> -->

    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/vendor/animsition/js/animsition.min.js"></script>
    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/vendor/bootstrap/js/popper.js"></script>
    <script src="LOGIN - SIGNUP/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/vendor/select2/select2.min.js"></script>
    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/vendor/daterangepicker/moment.min.js"></script>
    <script src="vendor/daterangepicker/daterangepicker.js"></script>
    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/vendor/countdowntime/countdowntime.js"></script>
    <!--===============================================================================================-->
    <script src="LOGIN - SIGNUP/js/main.js"></script>

</body>

</html>