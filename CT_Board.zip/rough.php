<?php
$gap = " ";
if (isset($_POST['submit'])) {

    $name = $_POST['name'];

    $filter = preg_replace('/\s/', '', $name);

    echo $filter;
}

?>

<form method="POST">
    <input type="text" name="name">
    <input type="submit" name="submit">
</form>