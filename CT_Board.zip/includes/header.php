<?php
ob_start();
session_start();
require("db.php");


if (!$_SESSION['email']) {
    header("location:index.php");
}

?>
<!DOCTYPE html>
<html>

<head>
    <title>CT Board</title>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">

    <meta name="description" content="A complete workable dynamic learning management system named CT Board developed by Tahsin Faruque">
    <meta property="og:image" content="img/logo.png">
    <meta name="keywords" content="html, css, javascript, jquery, php, mysql, coder tahsin, mahi tahsin,web developer; website builder; website designer; ecommerce website; codertahsin.com; Tahsin Faruque; best web developer in BD; bangladesh; ecommerce business; best motivator; Dhaka; Shikhbe Shobai; ForidRony; landing page; best programmer in bd; best programmer and web developer in fiverr; best programmer and web developer in upwork; best programmer and web developer in freelancer; best programmer and web developer in payperhour; weebly best website builder; shopify best website builder; squarespace best website builder; wordpress; best wordpress developer in Bangladesh; Pakistan; India; astra developer; avada developer; java; best php web developer, newsportal site,web design, SEO">
    <meta name="author" content="Tahsin Faruque">


    <link rel="icon" href="img/icon.ico">

    <!--Font Awesome CDN Version 5.15.1-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.1/css/all.css" integrity="sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp" crossorigin="anonymous">


    <!-- global stylesheets -->
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="font-awesome-4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/font-icon-style.css">
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">

    <!--Tahsin's Custom CSS-->
    <link rel="stylesheet" href="css/tahsin_faruque.css">


    <!-- Core stylesheets form -->
    <link rel="stylesheet" href="css/form.css">

    <!-- Core stylesheets media-->
    <link rel="stylesheet" href="css/apps/media.css">


</head>

<body>
    <?php
    include("topmenu.php");
    ?>