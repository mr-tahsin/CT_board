<h6 class="text-right" style="color: #525252;
    font-size: 10px;
    padding: 0;
    margin: 0;
    padding-top:15px;
    background-color: #eef5f9;
    padding-right: 22px;
    padding-bottom: 17px;"> &copy;2020. Rights reserved by <a href="https://codertahsin.com" target="_blank" class="unique_anchor">CT</a> | Version: 1.1.1 </h6>

<!--Global Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/popper/popper.min.js"></script>
<script src="js/tether.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery.cookie.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script src="js/chart.min.js"></script>
<script src="js/front.js"></script>

<!--Tahsin's Custom JS-->
<script src="js/tahsin.js"></script>


<!--Core Javascript-->
<script>
    new Chart(document.getElementById("myChart-nav").getContext('2d'), {
        type: 'doughnut',
        data: {
            labels: ["M", "T", "W", "T", "F", "S", "S"],
            datasets: [{
                backgroundColor: [
                    "#2ecc71",
                    "#3498db",
                    "#95a5a6",
                    "#9b59b6",
                    "#f1c40f",
                    "#e74c3c",
                    "#34495e"
                ],
                data: [12, 19, 3, 17, 28, 24, 7]
            }]
        },
        options: {
            legend: {
                display: false
            },
            title: {
                display: true,
                text: ''
            }
        }
    });
</script>

</body>

</html>

<?php
ob_end_flush();
?>