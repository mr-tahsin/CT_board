<?php
$db = mysqli_connect("codertahsin.com", "codertahsin", "tahsinfaruque96", "ct_board_php");
if ($db) {
    /* echo "Successfully connected"; */
} else {
    die("Database unable to connect. Please check your internet connection." . mysqli_error($db));
}
