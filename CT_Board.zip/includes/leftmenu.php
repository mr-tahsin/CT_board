<!--====================================================
                     LEFT MENU
======================================================-->
<style>
    .left_menu_img {
        -webkit-background-size: 32px 32px;
        background-size: 34px 32px;
        border: 0px;
        -webkit-border-radius: 50%;
        border-radius: 50%;
        display: block;
        margin: 0;
        position: relative;
        height: 47px;
        width: 47px;
        z-index: 0;
    }
</style>

<nav class="side-navbar">
    <div class="sidebar-header d-flex align-items-center">
        <div class="avatar">
            <?php
            if (empty($_SESSION['image']) && $_SESSION['gender'] == 1) { ?>
                <img src="img/user/default/male.png" alt="Profile picture" class="left_menu_img">

            <?php } else if (empty($_SESSION['image']) && $_SESSION['gender'] == 2) { ?> <img src="img/user/default/female.png" alt="Profile picture" class="left_menu_img">

            <?php } else if ($_SESSION['image']) { ?>
                <img src="img/user/<?php echo $_SESSION['image'] ?>" alt="Profile picture" class="left_menu_img">
            <?php }
            ?>
        </div>
        <div class="title">
            <h1 class="h4"><?php echo $_SESSION['fullname'] ?></h1>
            <?php
            if ($_SESSION['role'] == 2) { ?>
                <h6 class="text-muted" style="font-size: 13px;">STUDENT</h6>
            <?php }
            ?>
        </div>
    </div>
    <hr>
    <!-- Sidebar Navidation Menus-->
    <ul class="list-unstyled">

        <li><a href="dashboard.php"><i class="fas fa-laptop-house"></i>Home</a></li>

        <?php
        if ($_SESSION['role'] == 1) { ?>
            <span class="heading">Mentors</span>
            </li>

            <li><a href="#video_management" aria-expanded="false" data-toggle="collapse"><i class="fas fa-video"></i>Video Management</a>
                <ul id="video_management" class="collapse list-unstyled ">
                    <li><a href="video_mentor.php">All videos</a></li>
                    <li><a href="video_mentor.php?xun=add">Add new video</a></li>
                </ul>
            </li>

            <li>
                <a href="homework_mentor.php"> <i class="fas fa-book-medical"></i>Check Homeworks</a>
            </li>

            <li><a href="#course__management" aria-expanded="false" data-toggle="collapse"> <i class="fas fa-graduation-cap"></i>Course Management</a>
                <ul id="course__management" class="collapse list-unstyled ">
                    <li><a href="course.php">All courses</a></li>
                    <li><a href="course.php?xun=add">Add new course</a></li>
                </ul>
            </li>

            <li><a href="#student_management" aria-expanded="false" data-toggle="collapse"><i class="fas fa-user-graduate"></i>Student Management</a>
                <ul id="student_management" class="collapse list-unstyled ">
                    <li><a href="user.php">All students</a></li>
                    <li><a href="user.php?xun=add">Add new student</a></li>
                </ul>
            </li>



            <!-- <li> <a href="chart.html"> <i class="fa fa-bar-chart"></i>Chart </a></li>
            <li class=""><a href="#forms" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-building-o"></i>Forms </a>
                <ul id="forms" class="collapse list-unstyled">
                    <li class="active"><a href="basic-form.html">Basic Form</a></li>
                    <li><a href="form-layouts.html">Form Layouts</a></li>
                </ul>
            </li>
            <li> <a href="maps.html"> <i class="fa fa-map-o"></i>Maps </a></li>
            <li><a href="#pages" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-file-o"></i>Pages </a>
                <ul id="pages" class="collapse list-unstyled">
                    <li><a href="faq.html">FAQ</a></li>
                    <li><a href="empty.html">Empty</a></li>
                    <li><a href="gallery.html">Gallery</a></li>
                    <li><a href="login.html">Log In</a></li>
                    <li><a href="register.html">Register</a></li>
                    <li><a href="search-result.html">Search Result</a></li>
                    <li><a href="404.html">404</a></li>
                </ul>
            </li>
            <li> <a href="tables.html"> <i class="icon-grid"></i>Tables </a></li>
            <li><a href="#elements" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-globe"></i>UI Elements </a>
                <ul id="elements" class="collapse list-unstyled">
                    <li><a href="ui-buttons.html">Buttons</a></li>
                    <li><a href="ui-cards.html">Cards</a></li>
                    <li><a href="ui-progressbars.html">Progress Bar</a></li>
                    <li><a href="ui-timeline.html">Timeline</a></li>
                </ul>
            </li> -->

        <?php }
        ?>
    </ul>

    <span class="heading">Students</span>
    <ul class="list-unstyled">
        <li> <a href="video_student.php"> <i class="fas fa-play-circle"></i>Course Videos</a></li>
        <li> <a href="homework_student.php"> <i class="fas fa-book-reader"></i>Homework</a></li>
    </ul>
</nav>