<?php
ob_start();
session_start();
require("includes/db.php");
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Login &mdash; CT Board</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="A complete workable dynamic learning management system named CT Board developed by Tahsin Faruque">
	<meta property="og:image" content="img/logo.png">
	<meta name="keywords" content="html, css, javascript, jquery, php, mysql, coder tahsin, mahi tahsin,web developer; website builder; website designer; ecommerce website; codertahsin.com; Tahsin Faruque; best web developer in BD; bangladesh; ecommerce business; best motivator; Dhaka; Shikhbe Shobai; ForidRony; landing page; best programmer in bd; best programmer and web developer in fiverr; best programmer and web developer in upwork; best programmer and web developer in freelancer; best programmer and web developer in payperhour; weebly best website builder; shopify best website builder; squarespace best website builder; wordpress; best wordpress developer in Bangladesh; Pakistan; India; astra developer; avada developer; java; best php web developer, newsportal site,web design, SEO">
	<meta name="author" content="Tahsin Faruque">
	<!--===============================================================================================-->
	<link rel="icon" href="img/icon.ico" />
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/bootstrap/css/bootstrap.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/fonts/iconic/css/material-design-iconic-font.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/animate/animate.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/css-hamburgers/hamburgers.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/animsition/css/animsition.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/select2/select2.min.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/vendor/daterangepicker/daterangepicker.css">
	<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/css/util.css">
	<link rel="stylesheet" type="text/css" href="LOGIN - SIGNUP/css/main.css">
	<!--===============================================================================================-->

	<!--Tahsin's Custom CSS-->
	<link rel="stylesheet" href="LOGIN - SIGNUP/css/Tahsin_Faruque.css">
	<link rel="stylesheet" href="css/tahsin_faruque.css">
</head>

<body>

	<?php

	$failure_alert = "";
	if (isset($_POST['submit'])) {

		$email = mysqli_real_escape_string($db, $_POST['email']);
		$password = mysqli_real_escape_string($db, $_POST['password']);
		$secure_password = md5(sha1($password));

		$sql = "SELECT * FROM user WHERE user_email = '$email' ";
		$query = mysqli_query($db, $sql);
		$count_email = mysqli_num_rows($query);
		if ($count_email) {
			$sql = "SELECT * FROM user WHERE user_password = '$secure_password' ";
			$query = mysqli_query($db, $sql);
			$count_pass = mysqli_num_rows($query);
			if ($count_pass) {
				$sql = "SELECT * FROM user WHERE user_email = '$email' ";
				$query = mysqli_query($db, $sql);
				while ($row = mysqli_fetch_assoc($query)) {
					$_SESSION['id'] = $row['user_id'];
					$_SESSION['image'] = $row['user_pp'];
					$_SESSION['username'] = $row['user_username'];
					$_SESSION['fullname'] = $row['user_fullname'];
					$_SESSION['email'] = $row['user_email'];
					$_SESSION['password'] = $row['user_password'];
					$_SESSION['phone'] = $row['user_phone'];
					$_SESSION['address'] = $row['user_address'];
					$_SESSION['gender'] = $row['user_gender'];
					$_SESSION['course'] = $row['user_course'];
					$_SESSION['status'] = $row['user_status'];
					$_SESSION['role'] = $row['user_role'];
					$_SESSION['mentor_uniqueness'] =
						$row['mentor_uniqueness'];
				}

				if ($_SESSION['email'] == $email && $_SESSION['password'] == $secure_password) {
					header("location:dashboard.php");
				}
				if ($_SESSION['email'] == $email && $_SESSION['password'] == $secure_password && $_SESSION['status'] == 420) {
					header("location:inactive_student_msg.php");
				}
			} else {
				$failure_alert = '<div class="custom_alert" style = "color:#ff0090!important" >Password incorrect</div>';
			}
		} else {
			$failure_alert = '<div class="custom_alert" style = "color:#ff0090!important" >Your email doesn\'t match any account. <a href="signup.php" class="unique_anchor">Create new account</a></div>';
		}
	}
	?>


	<div class="limiter">
		<div class="container-login100" style="background-image: url('LOGIN - SIGNUP/images/bg-01.jpg');">
			<div class="wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54">

				<form class="login100-form validate-form" method="POST">
					<span class="login100-form-title p-b-49 ">
						CT Board Login
					</span>

					<?php
					echo $failure_alert;
					?>

					<div class="wrap-input100 validate-input m-b-23" data-validate="Email is required">
						<span class="label-input100">Email</span>
						<input class="input100" type="email" name="email" placeholder="Type your email">
						<span class="focus-input100" data-symbol="&#xf206;"></span>
					</div>

					<div class="wrap-input100 validate-input m-b-23" data-validate="Password is required">
						<span class="label-input100">Password</span>
						<input class="input100" type="password" name="password" placeholder="Type your password">
						<span class="focus-input100" data-symbol="&#xf190;"></span>
					</div>

					<div class="text-right p-t-8 p-b-31">
						<!-- <a href="#">
							Forgot password?
						</a> -->
					</div>

					<div class="container-login100-form-btn">
						<div class="wrap-login100-form-btn">
							<div class="login100-form-bgbtn"></div>
							<button class="login100-form-btn">
								Login
							</button>
							<input type="hidden" name="submit">
						</div>
					</div>



					<div class="flex-col-c p-t-30">
						<a href="signup.php" class="txt2 unique_anchor" style="text-transform: capitalize;">
							Create new account
						</a>
					</div>

					<div class="row mt-5">
						<div class="col-md-12">
							<a href="https://www.codertahsin.com/ctboard.html" target="_blank" class="btn btn-warning d-block">Click to get login details</a>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>


	<div id="dropDownSelect1"></div>

	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/vendor/jquery/jquery-3.2.1.min.js"></script>
	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/vendor/animsition/js/animsition.min.js"></script>
	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/vendor/bootstrap/js/popper.js"></script>
	<script src="LOGIN - SIGNUP/vendor/bootstrap/js/bootstrap.min.js"></script>
	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/vendor/select2/select2.min.js"></script>
	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/vendor/countdowntime/countdowntime.js"></script>
	<!--===============================================================================================-->
	<script src="LOGIN - SIGNUP/js/main.js"></script>

</body>

</html>
<?php
ob_end_flush();
?>