<html>
    <title>Inactive notice</title>
<link rel="icon" href="img/icon.ico" />

<body style="background:#EEF5F9; font-family:-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif">
    <div class="row">
        <div class="col-md-12">
            <h3>You have successfully registered. Please wait for some moment. You can enter to the <span style="color:#ff00a2">CT Board</span> when a mentor will approve you. </h3>
            <hr>
            <small><a href="https://codertahsin.com" style="color:#d840d9">Help</a> | <a href="https://codertahsin.com" style="color:#d840d9">Know more</a> | &copy;2020</small>
        </div>
    </div>
</body>

</html>