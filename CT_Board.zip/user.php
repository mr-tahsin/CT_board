<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>

    <!--CODE IS ART-->
    <?php

    if ($_SESSION['role'] == 1) {


        $variable = isset($_GET['xun']) ? $_GET['xun'] : "manage";

        if ($variable == "manage") { ?>

            <div class="content-inner">
                <h6 class="text-center alert-warning">All the passwords of all the students are 1 unless someone change it</h6>
                <h5>Student Management</h5>

                <!--***** CONTENT *****-->
                <div class="row">
                    <table class="table table-hover table-bordered table-responsive">
                        <thead>
                            <tr class="text-white" style="background: #b584bf!important">
                                <th>Action</th>
                                <th>#</th>
                                <th>Profile Picture</th>
                                <th>Username</th>
                                <th>Full Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Address</th>
                                <th>Gender</th>
                                <th>Course Enrolled</th>
                                <th>Status</th>
                                <th>Joined</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $sl = 1;
                            $sql = "SELECT * FROM user WHERE user_role = 2 ORDER BY user_id DESC";
                            $query = mysqli_query($db, $sql);
                            while ($row = mysqli_fetch_assoc($query)) {
                                $user_id = $row['user_id'];
                                $user_pp = $row['user_pp'];
                                $user_username = $row['user_username'];
                                $user_fullname = $row['user_fullname'];
                                $user_email = $row['user_email'];
                                $user_phone = $row['user_phone'];
                                $user_address = $row['user_address'];
                                $user_gender = $row['user_gender'];
                                $user_course = $row['user_course'];
                                $user_status = $row['user_status'];
                                $user_joined = $row['user_joined'];
                            ?>
                                <tr>
                                    <td>
                                        <ul>
                                            <li style="list-style: none;">
                                                <a href="#" data-toggle="modal" data-target="#deleteuser<?php echo $user_username; ?>" class="mr-1" style="color:#d657ab" data-toggle="tooltip" data-placement="top" title="Delete the information of this user"> <i class="fas fa-trash-alt"></i></a>


                                                <a href="user.php?xun=edit&edit_user=<?php echo $user_username; ?>" style="color:#62bede" data-toggle="tooltip" data-placement="top" title="Click to update the information of this user"><i class="fas fa-pen-nib"></i></a>
                                            </li>
                                        </ul>
                                    </td>
                                    <!-- DELETE MODAL START-->
                                    <div class="modal fade" id="deleteuser<?php echo $user_username; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog upor_theke_niche_margin" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">You are deleting all the information of <?php echo $user_fullname; ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-footer">
                                                    <a href="user.php?xun=delete&delete_user=<?php echo $user_username; ?>" class="btn mr-4" style="background-color:#d657ab; color:#fff;">Delete</a>
                                                    <button type="" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- DELETE MODAL END-->
                                    <td><?php echo $sl; ?></td>
                                    <td>
                                        <?php
                                        if ($user_pp) { ?>
                                            <img src="img/user/<?php echo $user_pp; ?>" alt="Profile picture" width="30" height="20">
                                        <?php } else if (empty($user_pp) && $user_gender == 1) { ?>
                                            <img src="img/user/default/male.png" alt="Profile picture" width="30">
                                        <?php } else if (empty($user_pp) && $user_gender == 2) { ?>
                                            <img src="img/user/default/female.png" alt="Profile picture" width="30">
                                        <?php }
                                        ?>
                                    </td>
                                    <td><?php echo $user_username; ?></td>
                                    <td><?php echo $user_fullname; ?> </td>
                                    <td><?php echo $user_email; ?> </td>
                                    <td>
                                        <?php
                                        if ($user_phone) {
                                            echo "+880-" . $user_phone;
                                        } else {
                                            echo '<span style="color: #d8a8c3;">N/A</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($user_address) {
                                            echo $user_address;
                                        } else {
                                            echo '<span style="color: #d8a8c3;">N/A</span>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($user_gender == 1) { ?>
                                            Male
                                        <?php } else if ($user_gender == 2) { ?>
                                            Female
                                        <?php }
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        $sql = "SELECT * FROM course WHERE course_id = '$user_course' ";
                                        $new_query = mysqli_query($db, $sql);
                                        while ($row = mysqli_fetch_assoc($new_query)) {
                                            $course_name = $row['course_name'];
                                        }
                                        echo $course_name;
                                        ?>
                                    </td>
                                    <td>
                                        <?php
                                        if ($user_status == 1) { ?>
                                            <span class="badge badge-pill" style="background: #59ce90;">Active student</span>
                                        <?php } else if ($user_status == 420) { ?>
                                            <span class="badge badge-pill" style="background: #d657ab;">Inactive student</span>
                                        <?php }
                                        ?>
                                    </td>
                                    <td><?php echo $user_joined; ?></td>
                                </tr>
                            <?php
                                $sl++;
                            }

                            ?>
                        </tbody>

                    </table>
                </div>

            </div>
        <?php }
        if ($variable == "add") { ?>

            <div class="content-inner chart-cont">

                <!--***** FORM LAYOUTS *****-->
                <div class="row">
                    <div class="col-md-12">

                        <!--***** USER INFO *****-->
                        <div class="card form" id="form1">
                            <div class="card-header">
                                <h3><i class="fa fa-user-circle"></i> Student's Info</h3>
                            </div>
                            <br>
                            <form method="POST" action="user.php?xun=insert" enctype="multipart/form-data">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="username">Username</label>
                                            <input type="text" class="form-control" id="username" placeholder="Enter username" name="username" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="fullname">Full name</label>
                                            <input type="text" class="form-control" id="fullname" placeholder="Enter fullname" name="fullname" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
                                        </div>
                                        <fieldset class="form-group">
                                            <label>Gender</label>
                                            <div class="form-check">
                                                <label class="form-check-label mr-2">
                                                    <input type="radio" class="form-check-input" name="gender" id="gender" value="1" required> Male
                                                </label>
                                                <label class="form-check-label">
                                                    <input type="radio" class="form-check-input" name="gender" id="gender" value="2" required> Female
                                                </label>
                                            </div>
                                        </fieldset>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Select a course</label>

                                            <?php
                                            $sql = "SELECT * FROM course WHERE course_status = 1";
                                            $query = mysqli_query($db, $sql);
                                            $course_count = mysqli_num_rows($query);
                                            if ($course_count == 0) { ?>
                                                <select class="form-control" name="course" required>
                                                    <option value="420">Sorry, no course is available now.</option>
                                                </select>
                                            <?php } else { ?>

                                                <select class="form-control" name="course" required>
                                                    <?php
                                                    $sql = "SELECT * FROM  course WHERE course_status = 1 ORDER BY course_id DESC";
                                                    $query = mysqli_query($db, $sql);
                                                    while ($row = mysqli_fetch_assoc($query)) {
                                                        $course_id = $row['course_id'];
                                                        $course_name = $row['course_name'];
                                                    ?>
                                                        <option value="<?php echo $course_id; ?>"><?php echo $course_name; ?></option>
                                                    <?php }
                                                    ?>
                                                </select>
                                            <?php }
                                            ?>

                                        </div>
                                        <fieldset class="form-group">
                                            <label>Status</label>
                                            <div class="form-check">
                                                <label class="form-check-label mr-2">
                                                    <input type="radio" class="form-check-input" name="status" id="status" value="1" required> Active
                                                </label>
                                                <label class="form-check-label">
                                                    <input type="radio" class="form-check-input" name="status" id="status" value="420" required> Inactive
                                                </label>
                                            </div>
                                        </fieldset>
                                        <div class="form-group">
                                            <label class="d-block">Profile picture (optional) <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="Profile picture has to be in jpg, jpeg, or in png format and must be in less than 200 KB."></i></label>
                                            <input type="file" class="form-control-file" name="image">
                                            <small id="fileHelp" class="form-text text-muted">Select a profile picture of your own.</small>
                                        </div>
                                    </div>
                                </div>
                                <!--contact-->
                                <div class="row mt-4">
                                    <div class="col-md-12">
                                        <h3 style="border-bottom: 1px solid #ddd;">Contact</h3>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone">Phone (optional)</label>
                                            <input type="number" class="form-control" id="phone" placeholder="i.e. 01855414342" name="phone">
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="address">Address (optional)</label>
                                            <input type="text" class="form-control" id="address" placeholder="Enter address" name="address">
                                        </div>
                                    </div>
                                </div>

                                <!--security-->
                                <div class="row mt-4">
                                    <div class="col-md-12">
                                        <h3 style="border-bottom: 1px solid #ddd;">Security</h3>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="phone">Password</label>
                                            <input type="password" class="form-control" name="password" placeholder="Enter password" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="address">Retype password</label>
                                            <input type="password" class="form-control" name="repassword" placeholder="Enter password again" required>
                                        </div>
                                    </div>
                                </div>


                                <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">

                                <input type="submit" class="btn btn-general" value="Add" style="color:#495057; border:0.7px solid #7ca4c7">

                                <input type="hidden" name="add_user">
                            </form>
                        </div>

                    </div>
                </div>

            </div>

        <?php }
        if ($variable == "insert") {


            date_default_timezone_set("Asia/Dhaka");
            $bd_date = date("(h:i:s A, D, d M, Y)");

            if (isset($_POST['add_user'])) {

                $username = mysqli_real_escape_string($db, $_POST['username']);
                $fullname = mysqli_real_escape_string($db, $_POST['fullname']);
                $email = mysqli_real_escape_string($db, $_POST['email']);
                $phone = mysqli_real_escape_string($db, $_POST['phone']);
                $address = mysqli_real_escape_string($db, $_POST['address']);
                $gender = mysqli_real_escape_string($db, $_POST['gender']);
                $course = mysqli_real_escape_string($db, $_POST['course']);
                $status = mysqli_real_escape_string($db, $_POST['status']);
                $password = mysqli_real_escape_string($db, $_POST['password']);
                $repassword = mysqli_real_escape_string($db, $_POST['repassword']);

                ///image validation
                $image_name = mysqli_real_escape_string($db, $_FILES['image']['name']);
                $image_tmp_name = $_FILES['image']['tmp_name'];
                $image_size = $_FILES['image']['size'];

                $image_formats = array('jpg', 'png', 'jpeg');
                $explode = explode('.', $image_name);
                $end = end($explode);
                ///

                /// insert with image 
                if (!empty($image_name)) {

                    //Jodi phone no. 11 digit na hoi then mara,,, 
                    $strlen = strlen($phone);
                    $limits = 11;
                    $limit = 0;
                    if ($strlen == $limits or $strlen == $limit) {

                        //same username alert...
                        $sql = "SELECT * FROM user WHERE user_username = '$username' ";
                        $query = mysqli_query($db, $sql);
                        $count_username = mysqli_num_rows($query);
                        if (!$count_username > 0) {
                            //same email alert...
                            $sql = "SELECT * FROM user WHERE user_email = '$email' ";
                            $query = mysqli_query($db, $sql);
                            $count_email = mysqli_num_rows($query);
                            if (!$count_email > 0) {

                                // remove spaces from username...
                                $remove_space_username = preg_replace('/\s/', '', $username);

                                if ($password == $repassword) {
                                    $secure_password = md5(sha1($password));
                                    if ($image_size > 200000) {
                                        echo '<span class="text-danger mt-3 ml-3">The profile picture must be less than 200 Kilobytes. <a href="user.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                                    } else if (!in_array($end, $image_formats)) {
                                        echo '<span class="text-danger mt-3 ml-3">The profile picture has to be in jpg, jpeg, or png format. <a href="user.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                                    } else if ($course == 420) {
                                        echo '<span class="text-danger mt-3 ml-3">Sorry, no course is running now. </span>';
                                    } else {
                                        move_uploaded_file($image_tmp_name, 'img/user/' . $image_name);

                                        $sql = "INSERT INTO user (user_pp, user_username, user_fullname, 	user_email, user_password, user_phone, user_address, user_gender, user_course, user_status, user_role, user_joined) VALUES ('$image_name','$remove_space_username','$fullname','$email','$secure_password','$phone','$address','$gender','$course','$status', 2, '$bd_date' )";
                                        $query = mysqli_query($db, $sql);
                                        if ($query) {
                                            echo '<span class="text-success mt-3 ml-3">Student added successfully. <a href="user.php?xun=add" class="unique_anchor">Click</a> to add a new student. <a href="user.php?xun=manage" class="unique_anchor">Click</a> to see all students.</span>';
                                        } else {
                                            die("Operation failed" . mysqli_error($db));
                                        }
                                    }
                                } else {
                                    echo '<span class="text-danger mt-3 ml-3">Password didn\'t match. <a href="user.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                                }
                            } else {
                                echo '<span class="text-danger mt-3 ml-3">Email already used. Please give another one.</span>';
                            }
                        } else {
                            echo '<span class="text-danger mt-3 ml-3">Username already taken. Please try another one.</span>';
                        }
                    } else {
                        echo '<span class="text-danger mt-3 ml-3">The phone number has to be in 11 digits. <a href="user.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                    }

                    /// insert without image 
                } else {

                    $strlen = strlen($phone);
                    $limits = 11;
                    $limit = 0;
                    if ($strlen == $limit or $strlen == $limits) {

                        //same username alert...
                        $sql = "SELECT * FROM user WHERE user_username = '$username' ";
                        $query = mysqli_query($db, $sql);
                        $count_username = mysqli_num_rows($query);
                        if (!$count_username > 0) {

                            //same email alert...
                            $sql = "SELECT * FROM user WHERE user_email = '$email' ";
                            $query = mysqli_query($db, $sql);
                            $count_email = mysqli_num_rows($query);
                            if (!$count_email > 0) {

                                // remove spaces from username...
                                $remove_space_username = preg_replace('/\s/', '', $username);

                                if ($password == $repassword) {
                                    $secure_password = md5(sha1($password));
                                    if ($course == 420) {
                                        echo '<span class="text-danger mt-3 ml-3">Sorry, no course is running now.</span>';
                                    } else {

                                        $sql = "INSERT INTO user (user_username, user_fullname, user_email, user_password, user_phone, user_address, user_gender, user_course, user_status, user_role, user_joined) VALUES ('$remove_space_username','$fullname','$email','$secure_password','$phone','$address','$gender','$course','$status', 2, '$bd_date' )";
                                        $query = mysqli_query($db, $sql);
                                        if ($query) {
                                            echo '<span class="text-success mt-3 ml-3">Student added successfully. <a href="user.php?xun=add" class="unique_anchor">Click</a> to add a new student. <a href="user.php?xun=manage" class="unique_anchor">Click</a> to see all students.</span>';
                                        } else {
                                            die("Operation failed" . mysqli_error($db));
                                        }
                                    }
                                } else {
                                    echo '<span class="text-danger mt-3 ml-3">Password didn\'t match. <a href="user.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                                }
                            } else {
                                echo '<span class="text-danger mt-3 ml-3">Email already used. Please give another one.</span>';
                            }
                        } else {
                            echo '<span class="text-danger mt-3 ml-3">Username already taken. Please try another one.</span>';
                        }
                    } else {
                        echo '<span class="text-danger mt-3 ml-3">The phone number has to be in 11 digits. <a href="user.php?xun=add" class="unique_anchor">Click</a> to go back.</span>';
                    }
                }
            }
        }
        if ($variable == "edit") { ?>
            <div class="content-inner chart-cont">

                <!--***** FORM LAYOUTS *****-->
                <div class="row">
                    <div class="col-md-12">

                        <!--***** USER INFO *****-->
                        <div class="card form" id="form1">

                            <?php
                            if (isset($_GET['edit_user'])) {
                                $store_edit = $_GET['edit_user'];

                                $sql = "SELECT * FROM user WHERE user_username = '$store_edit' ";
                                $query = mysqli_query($db, $sql);
                                while ($row = mysqli_fetch_assoc($query)) {
                                    $user_id = $row['user_id'];
                                    $user_pp = $row['user_pp'];
                                    $user_username = $row['user_username'];
                                    $user_fullname = $row['user_fullname'];
                                    $user_email = $row['user_email'];
                                    $user_phone = $row['user_phone'];
                                    $user_address = $row['user_address'];
                                    $user_gender = $row['user_gender'];
                                    $user_course = $row['user_course'];
                                    $user_status = $row['user_status'];
                            ?>
                                    <div class="card-header">
                                        <h3><i class="fa fa-user-circle"></i> Edit <?php echo $user_fullname . "'s"; ?> Info</h3>
                                    </div>
                                    <br>

                                    <form method="POST" action="user.php?xun=update" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="username">Username <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="Username can not be change."></i></label>
                                                    <input type="text" class="form-control" style="color:#ff00b5;" id="username" value="<?php echo $user_username; ?>" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label for="fullname">Full name</label>
                                                    <input type="text" class="form-control" style="color:#ff00b5;" id="fullname" value="<?php echo $user_fullname; ?>" name="fullname">
                                                </div>
                                                <div class="form-group">
                                                    <label for="email">Email address <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="Email can not be change."></i></label>
                                                    <input type="email" class="form-control" id="email" style="color:#ff00b5;" value="<?php echo $user_email; ?>" readonly>
                                                </div>
                                                <div class="form-group">
                                                    <label>Gender</label>
                                                    <div class="custom_color_radio">
                                                        <input name="gender" value="1" type="radio" id="radio_for_male" <?php if ($user_gender == 1) {
                                                                                                                            echo "checked";
                                                                                                                        }  ?>>
                                                        <label for="radio_for_male">Male</label>

                                                        <input name="gender" value="2" type="radio" id="radio_for_female" <?php
                                                                                                                            if ($user_gender == 2) {
                                                                                                                                echo "checked";
                                                                                                                            }  ?>>
                                                        <label for="radio_for_female">Female</label>

                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label>Edit course</label>
                                                    <select class="form-control" style="color:#ff00b5;" name="course">
                                                        <?php
                                                        $sql = "SELECT * FROM  course WHERE course_status = 1 ORDER BY course_id DESC";
                                                        $query = mysqli_query($db, $sql);
                                                        while ($row = mysqli_fetch_assoc($query)) {
                                                            $course_id = $row['course_id'];
                                                            $course_name = $row['course_name'];
                                                        ?>
                                                            <option value="<?php echo $course_id; ?>">
                                                                <?php
                                                                echo $course_name;
                                                                ?>
                                                            </option>
                                                        <?php }
                                                        ?>
                                                        }
                                                    </select>
                                                </div>
                                                <div class="form-group">
                                                    <label>Status</label>
                                                    <div class="custom_color_radio">
                                                        <input name="status" value="1" type="radio" id="status_for_active" <?php if ($user_status == 1) {
                                                                                                                                echo "checked";
                                                                                                                            }  ?>>
                                                        <label for="status_for_active">Active</label>

                                                        <input name="status" value="420" type="radio" id="status_for_inactive" <?php if ($user_status == 420) {
                                                                                                                                    echo "checked";
                                                                                                                                }  ?>>
                                                        <label for="status_for_inactive">Inactive</label>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="d-block">Profile picture (optional) <i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="The profile picture has to be in jpg, jpeg, or in png format and must be in less than 200 KB."></i></label>
                                                    <input type="file" class="form-control-file" name="profile_picture">
                                                    <?php
                                                    if (empty($user_pp) and $user_gender == 1) { ?>
                                                        <small id="fileHelp" class="form-text text-muted">You can select a profile picture for this user</small>
                                                        <img src="img/user/default/male.png" width="30" alt="Profile picture" class="mt-2 unique_img_edit">

                                                    <?php } else if (empty($user_pp) and $user_gender == 2) { ?>
                                                        <small id="fileHelp" class="form-text text-muted">You can select a profile picture for this user</small>
                                                        <img src="img/user/default/female.png" width="30" alt="Profile picture" class="mt-2 unique_img_edit">

                                                    <?php } else if ($user_pp) { ?>
                                                        <img src="img/user/<?php echo $user_pp; ?>" width="30" alt="Profile picture" class="mt-2 unique_img_edit">
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>

                                        <!--contact-->
                                        <div class="row mt-4">
                                            <div class="col-md-12">
                                                <h3 style="border-bottom: 1px solid #ddd;">Contact</h3>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="phone">Phone (optional)</label>
                                                    <?php
                                                    if (!$user_phone) { ?>
                                                        <input type="number" class="form-control" id="phone" placeholder="i.e. 01855414342" name="phone">
                                                    <?php } else { ?>
                                                        <input type="number" class="form-control" id="phone" style="color:#ff00b5;" value="<?php echo "0" . $user_phone; ?>" name="phone">
                                                    <?php }  ?>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="address">Address (optional)</label>
                                                    <?php
                                                    if (!$user_address) { ?>
                                                        <input type="text" class="form-control" id="address" style="color:#ff00b5;" placeholder="222/1, Malibag, Dhaka" name="address">
                                                    <?php } else { ?>
                                                        <input type="text" class="form-control" id="address" style="color:#ff00b5;" value="<?php echo $user_address; ?>" name="address">
                                                    <?php }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>

                                        <!--security-->
                                        <div class="row mt-4">
                                            <div class="col-md-12">
                                                <h3 style="border-bottom: 1px solid #ddd;">Security</h3>
                                            </div>
                                        </div>
                                        <div class="row mt-3">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="phone">Password</label>
                                                    <input type="password" class="form-control" name="password" placeholder="Enter new password">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="address">Retype password</label>
                                                    <input type="password" class="form-control" name="repassword" placeholder="Enter new password again">
                                                </div>
                                            </div>
                                        </div>


                                        <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">

                                        <input type="submit" class="btn btn-general" value="Save Changes" style="color:#495057; border:0.7px solid #7ca4c7">

                                        <input type="hidden" name="update_user" value="<?php echo $user_username; ?>">
                        </div>
                        <!--Card-->
                        </form>

                <?php } //while end
                            } ?>
                    </div>
                    <!--Column-->

                </div>
                <!--Row-->
            </div>
            <!--content-inner chart-cont-->


    <?php }
        if ($variable == "update") {

            if (isset($_POST['update_user'])) {
                $store_update = $_POST['update_user'];

                $user_fullname = mysqli_real_escape_string($db, $_POST['fullname']);
                $user_gender = mysqli_real_escape_string($db, $_POST['gender']);
                $user_course = mysqli_real_escape_string($db, $_POST['course']);
                $user_status = mysqli_real_escape_string($db, $_POST['status']);
                $user_phone = mysqli_real_escape_string($db, $_POST['phone']);
                $user_address = mysqli_real_escape_string($db, $_POST['address']);
                $user_password = mysqli_real_escape_string($db, $_POST['password']);
                $user_repassword = mysqli_real_escape_string($db, $_POST['repassword']);

                ///Image validation
                $user_pp_name = mysqli_real_escape_string($db, $_FILES['profile_picture']['name']);
                $user_pp_tmp_name = $_FILES['profile_picture']['tmp_name'];
                $user_pp_size = $_FILES['profile_picture']['size'];
                $explode = explode('.', $user_pp_name);
                $end = end($explode);
                $user_pp_format = array('jpg', 'jpeg', 'png');
                ///


                if ($user_password == $user_repassword) {

                    //Only for course
                    if (!empty($user_course)) {
                        $sql = "UPDATE user SET user_course = '$user_course' WHERE user_username = '$store_update' ";
                        $query = mysqli_query($db, $sql);
                        if ($query) {
                            header("location:user.php?xun=manage");
                        } else {
                            die("Operation failed" . mysqli_error($db));
                        }
                    }

                    //With image 
                    if (!empty($user_pp_name)) {
                        if ($user_pp_size > 200000) {
                            echo '<span class="text-danger mt-3 ml-3">The profile picture must be less than 200 Kilobytes.</span>';
                        } else if (!in_array($end, $user_pp_format)) {
                            echo '<span class="text-danger mt-3 ml-3">The profile picture has to be in jpg, jpeg, or png format.</span>';
                        } else {

                            //phone number 11 digit na dile mara,,,
                            $strlen = strlen($user_phone);
                            $limits = 11;
                            $limit = 0;
                            if ($strlen == $limits or $strlen == $limit) {

                                $secure_password = md5(sha1($user_password));

                                move_uploaded_file($user_pp_tmp_name, "img/user/" . $user_pp_name);

                                $sql = "UPDATE user SET user_pp = '$user_pp_name', user_password = '$secure_password', user_fullname = '$user_fullname', user_phone = '$user_phone', user_address = '$user_address', user_gender = '$user_gender', user_status = '$user_status' WHERE user_username = '$store_update' ";
                                $query = mysqli_query($db, $sql);
                                if ($query) {
                                    /* echo '<span class="text-success mt-3 ml-3">Student\'s info updated successfully. <a href="user.php?xun=manage" class="unique_anchor">Click</a> to see all students.</span>'; */
                                    header("location:user.php?xun=manage");
                                } else {
                                    die("Operation failed" . mysqli_error($db));
                                }
                            } else {
                                echo '<span class="text-danger mt-3 ml-3">The phone number has to be in 11 digits.</span>';
                            }
                        }
                    } else {

                        //phone number 11 digit na dile mara,,,
                        $strlen = strlen($user_phone);
                        $limits = 11;
                        $limit = 0;
                        if ($strlen == $limits or $strlen == $limit) {

                            $secure_password = md5(sha1($user_password));


                            $sql = "UPDATE user SET user_password = '$secure_password', user_fullname = '$user_fullname', user_phone = '$user_phone', user_address = '$user_address', user_gender = '$user_gender', user_status = '$user_status' WHERE user_username = '$store_update' ";
                            $query = mysqli_query($db, $sql);
                            if ($query) {
                                header("location:user.php?xun=manage");
                            } else {
                                die("Operation failed" . mysqli_error($db));
                            }
                        } else {
                            echo '<span class="text-danger mt-3 ml-3">The phone number has to be in 11 digits.</span>';
                        }
                    }
                } else {
                    echo '<span class="text-danger mt-3 ml-3">Password didn\'t match.</span>';
                }
            }
        }
        if ($variable == "delete") {
            if (isset($_GET['delete_user'])) {
                $store_delete = $_GET['delete_user'];

                $sql = "DELETE FROM user WHERE user_username = '$store_delete' ";
                $query = mysqli_query($db, $sql);
                if ($query) {
                    echo '<span class="text-success mt-3 ml-3">Successfully deleted. <a href="user.php?xun=manage" class="unique_anchor">Click</a> to see all students.</span>';
                } else {
                    die("Operation failed" . mysqli_error($db));
                }
            }
        }
    } //Session role 1 na hole mara...
    ?>


</div>
<!--Page content-->

<?php
include("includes/footer.php")
?>