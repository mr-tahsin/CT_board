<?php
include("includes/header.php")
?>

<div class="page-content d-flex align-items-stretch">

    <?php
    include("includes/leftmenu.php");
    ?>


    <!--CODE IS ART-->

    <?php
    $variable = isset($_GET['xun']) ? $_GET['xun'] : "add";

    if ($variable == "add") { ?>
        <div class="content-inner form-cont">
            <div class="row">
                <div class="col-md-12">
                    <div class="card form">
                        <div class="card-header">
                            <h3 class="card-title">Submit Your Homework</h3>
                        </div>
                        <br>
                        <form action="homework_student.php?xun=insert" method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-7">
                                    <div class="form-group">
                                        <label>Homework name</label>
                                        <input type="text" class="form-control" placeholder="Logo design" name="name">
                                    </div>
                                    <div class="form-group">
                                        <label>Homework details (optional)</label>
                                        <textarea class="form-control" rows="3" style="border-radius: 0;" placeholder="Ami side er ongsho tuku korte pari nai." name="details"></textarea>
                                    </div>
                                    <div class="form-group">
                                        <label>Additional link (optional)</label>
                                        <input type="text" class="form-control" placeholder="https://codertahsin.com" name="link">
                                    </div>
                                    <div class="form-group">
                                        <label class="d-block">Homework file<i class="far fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="The homework file has to be in jpg, jpeg, png, pdf, mp4, 3gp or in zip format and must be in less than 7 MB."></i></label>
                                        <input type="file" class="form-control-file" name="file">
                                        <small id="fileHelp" class="form-text text-muted">Check your file before upload.</small>
                                    </div>
                                </div>
                            </div>
                            <input type="reset" class="btn btn-general mr-2" value="Reset" style="color:#495057;border:0.7px solid #d06b9e">
                            <input type="submit" class="btn btn-general " value="Submit" style="color:#495057; border:0.7px solid #7ca4c7" name="submit">
                        </form>
                    </div>

                </div>
            </div>
        </div>

    <?php } else if ($variable == "insert") {

        date_default_timezone_set("Asia/Dhaka");
        $bd_date = date("(h:i:s A, D, d M, Y)");

        if (isset($_POST['submit'])) {
            $name = mysqli_real_escape_string($db, $_POST['name']);
            $details = mysqli_real_escape_string($db, $_POST['details']);
            $link = mysqli_real_escape_string($db, $_POST['link']);

            // for file validation
            $file_name = mysqli_real_escape_string($db, $_FILES['file']['name']);
            $file_tmp_name = $_FILES['file']['tmp_name'];
            $file_size = $_FILES['file']['size'];
            $formats = array('jpg', 'jpeg', 'png', '3gp', 'mp4', 'pdf', 'zip');
            $explode = explode('.', $file_name);
            $end = end($explode);

            if (!empty($name)) {
                if (!empty($file_name)) {
                    if ($file_size < 7000000) {
                        if (in_array($end, $formats)) {
                            move_uploaded_file($file_tmp_name, 'img/homework/' . $file_name);

                            $session_fullname = $_SESSION['fullname'];
                            $session_course = $_SESSION['course'];

                            $sql = "INSERT INTO homework (submitted_by, course_enrolled, name, details, link, file, submit_date) VALUES ('$session_fullname', '$session_course', '$name', '$details', '$link', '$file_name', '$bd_date') ";
                            $query = mysqli_query($db, $sql);
                            if ($query) {
                                echo '<span class="text-success mt-3 ml-3" style="height:100vh!important;">You have successfully submitted your homework. <a href="homework_student.php?xun=add" class="unique_anchor">Click</a> to submit another.</span>';
                            } else {
                                die("Operation failed. Please check your internet connection or email at contact@codertahsin.com if necessary" . mysqli_error($query));
                            }
                        } else {
                            echo '<span class="text-danger mt-3 ml-3">The file has to be in jpg, jpeg, png, 3gp, mp4, pdf or in zip format.</span>';
                        }
                    } else {
                        echo '<span class="text-danger mt-3 ml-3">The homework file has to be smaller than 7 MB.</span>';
                    }
                } else {
                    echo '<span class="text-danger mt-3 ml-3">You didn\'t select any homework file. </span>';
                }
            } else {
                echo '<span class="text-danger mt-3 ml-3">You have to give a name of your homework. </span>';
            }
        }
    }

    ?>




</div>

<?php
include("includes/footer.php");
?>